package hr.josippozega.tusglava

import org.json.JSONObject
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

private const val FILTER_TOTAL_OFFSET = 0x0256
private const val FILTER_WARNING_OFFSET = 0x0258
private const val TEMP_HIGH_OFFSET = 0x025A
private const val TEMP_HOT_OFFSET = 0x025C
private const val TEMP_COLD_OFFSET = 0x025E

private const val USAGE_OFFSET = 0x0290
private const val USAGE_MIRROR_OFFSET = 0x0292
private const val REMAINING_OFFSET = 0x0294
private const val REMAINING_MIRROR_OFFSET = 0x0296
private val TEMPERATURE_OFFSETS = intArrayOf(0x0298, 0x029C, 0x02A0, 0x02A4)

private const val SESSION_TABLE_OFFSET = 0x0401
private const val SESSION_RECORD_SIZE = 28
private const val SESSION_MAX_RECORDS = 32
private const val ACTIVE_TIMER_OFFSET = 0x02C4
private const val ACTIVE_TIMER_BASE = 978_307_200L

private const val EST_FLOW_LPM = 8.0
private const val EST_FLOW_MIN_LPM = 6.0
private const val EST_FLOW_MAX_LPM = 9.0

/**
 * Decoded, user-facing view of the proprietary Hello Klean EEPROM fields.
 *
 * Confidence labels deliberately distinguish repeatably verified values from
 * values that are still inferred from controlled differential scans.
 */
data class ShowerMetrics(
    val temperatureC: Double?,
    val temperatureRaw: Int?,
    val filterTotalUnits: Int?,
    val filterWarningUsedUnits: Int?,
    val filterUsedUnits: Int?,
    val filterRemainingUnits: Int?,
    val filterRemainingPercent: Double?,
    val hotThresholdC: Double?,
    val highThresholdC: Double?,
    val coldThresholdC: Double?,
    val currentRecordIndex: Int?,
    val currentSessionSecondsEstimate: Double?,
    val hotSecondsTotal: Int?,
    val coldSecondsTotal: Int?,
    val intervalSeconds: Double?,
    val estimatedIntervalLiters: Double?,
    val estimatedIntervalLitersMin: Double?,
    val estimatedIntervalLitersMax: Double?,
    val usageUnitsDelta: Int?,
    val hotSecondsDelta: Int?,
    val coldSecondsDelta: Int?,
    val hasHelloKleanHeader: Boolean,
    val notes: List<String>
) {
    fun toJson(): JSONObject = JSONObject().apply {
        putNullableLocal("temperature_c", temperatureC)
        putNullableLocal("temperature_raw_deci_c", temperatureRaw)
        put("temperature_confidence", if (temperatureC != null) "high" else "unavailable")

        putNullableLocal("filter_total_units", filterTotalUnits)
        putNullableLocal("filter_warning_used_units", filterWarningUsedUnits)
        putNullableLocal("filter_used_units", filterUsedUnits)
        putNullableLocal("filter_remaining_units", filterRemainingUnits)
        putNullableLocal("filter_remaining_percent", filterRemainingPercent)
        put("filter_counter_confidence", if (filterTotalUnits != null && filterRemainingUnits != null) "high_structure_medium_unit" else "unavailable")

        putNullableLocal("threshold_hot_c", hotThresholdC)
        putNullableLocal("threshold_high_c", highThresholdC)
        putNullableLocal("threshold_cold_c", coldThresholdC)

        putNullableLocal("current_record_index", currentRecordIndex)
        putNullableLocal("current_session_seconds_estimate", currentSessionSecondsEstimate)
        putNullableLocal("hot_seconds_total", hotSecondsTotal)
        putNullableLocal("cold_seconds_total", coldSecondsTotal)
        put("session_field_confidence", if (currentRecordIndex != null) "medium_offset_verified" else "unavailable")

        putNullableLocal("interval_seconds", intervalSeconds)
        putNullableLocal("estimated_interval_liters", estimatedIntervalLiters)
        putNullableLocal("estimated_interval_liters_min", estimatedIntervalLitersMin)
        putNullableLocal("estimated_interval_liters_max", estimatedIntervalLitersMax)
        put("liters_basis", "procjena iz vremena protoka uz 8,0 L/min; raspon 6–9 L/min")

        putNullableLocal("usage_units_delta", usageUnitsDelta)
        putNullableLocal("hot_seconds_delta", hotSecondsDelta)
        putNullableLocal("cold_seconds_delta", coldSecondsDelta)
        put("hello_klean_header_detected", hasHelloKleanHeader)
        put("notes", org.json.JSONArray(notes))
    }
}

private data class SessionRecord(
    val offset: Int,
    val clockRaw: Long,
    val index: Int,
    val fields: IntArray
)

object ShowerMetricsDecoder {
    fun decode(previousJson: String?, snapshot: NfcSnapshot): ShowerMetrics {
        val current = snapshot.metadata["NfcV.memory.dump_hex"].orEmpty().hexBytesOrNull()
        if (current == null || current.size < 8192) {
            return ShowerMetrics(
                temperatureC = null,
                temperatureRaw = null,
                filterTotalUnits = null,
                filterWarningUsedUnits = null,
                filterUsedUnits = null,
                filterRemainingUnits = null,
                filterRemainingPercent = null,
                hotThresholdC = null,
                highThresholdC = null,
                coldThresholdC = null,
                currentRecordIndex = null,
                currentSessionSecondsEstimate = null,
                hotSecondsTotal = null,
                coldSecondsTotal = null,
                intervalSeconds = null,
                estimatedIntervalLiters = null,
                estimatedIntervalLitersMin = null,
                estimatedIntervalLitersMax = null,
                usageUnitsDelta = null,
                hotSecondsDelta = null,
                coldSecondsDelta = null,
                hasHelloKleanHeader = false,
                notes = listOf("EEPROM nije potpuno pročitan; Smart Dashboard nije dekodiran.")
            )
        }

        val previousRoot = previousJson?.let { runCatching { JSONObject(it) }.getOrNull() }
        val previousBytes = previousRoot
            ?.optJSONObject("technology_metadata")
            ?.optString("NfcV.memory.dump_hex")
            .orEmpty()
            .hexBytesOrNull()
            ?.takeIf { it.size == current.size }

        val total = current.u16leSafe(FILTER_TOTAL_OFFSET)?.takeIf { it in 1000..20000 }
        val warning = current.u16leSafe(FILTER_WARNING_OFFSET)?.takeIf { it in 0..20000 }
        val usedA = current.u16leSafe(USAGE_OFFSET)
        val usedB = current.u16leSafe(USAGE_MIRROR_OFFSET)
        val remainingA = current.u16leSafe(REMAINING_OFFSET)
        val remainingB = current.u16leSafe(REMAINING_MIRROR_OFFSET)
        val used = mirroredValue(usedA, usedB)
        val remaining = mirroredValue(remainingA, remainingB)
        val remainingPercent = if (total != null && remaining != null && total > 0) {
            (remaining.toDouble() / total.toDouble() * 100.0).coerceIn(0.0, 100.0)
        } else null

        val temperatureRaw = TEMPERATURE_OFFSETS
            .map { current.u16leSafe(it) }
            .filterNotNull()
            .filter { it in 0..1000 }
            .let { values ->
                if (values.isEmpty()) {
                    null
                } else {
                    val mostCommon = values.groupingBy { it }.eachCount().maxByOrNull { it.value }
                    if ((mostCommon?.value ?: 0) >= 2) mostCommon?.key
                    else values.sorted()[values.size / 2]
                }
            }
        val temperatureC = temperatureRaw?.div(10.0)

        val highThresholdC = current.u16leSafe(TEMP_HIGH_OFFSET)?.takeIf { it in 100..700 }?.div(10.0)
        val hotThresholdC = current.u16leSafe(TEMP_HOT_OFFSET)?.takeIf { it in 100..700 }?.div(10.0)
        val coldThresholdC = current.u16leSafe(TEMP_COLD_OFFSET)?.takeIf { it in 0..700 }?.div(10.0)

        val records = parseSessionRecords(current)
        val latest = records.maxByOrNull { it.index }
        val previousRecordInTable = latest?.let { now -> records.filter { it.index < now.index }.maxByOrNull { it.index } }
        val currentSessionSecondsEstimate = if (latest != null && previousRecordInTable != null && latest.clockRaw >= previousRecordInTable.clockRaw) {
            (latest.clockRaw - previousRecordInTable.clockRaw) / 10.0
        } else null

        // Controlled scans identified field 7 as hot-time and field 8 as cold-time candidates.
        val hotTotal = latest?.fields?.getOrNull(7)
        val coldTotal = latest?.fields?.getOrNull(8)

        val previousRecords = previousBytes?.let(::parseSessionRecords).orEmpty()
        val previousLatest = latest?.let { now -> previousRecords.firstOrNull { it.index == now.index } }

        // The global 10 Hz activity counter at 0x02C4 was validated by the 60 s cold-water
        // experiment (+600 ticks). Use it for between-scan interval timing because it
        // remains stable even if the current session-record slot changes.
        val currentActiveTimer = current.u32leSafe(ACTIVE_TIMER_OFFSET)
        val previousActiveTimer = previousBytes?.u32leSafe(ACTIVE_TIMER_OFFSET)
        val intervalSeconds = if (currentActiveTimer != null && previousActiveTimer != null && currentActiveTimer >= previousActiveTimer) {
            ((currentActiveTimer - previousActiveTimer) / 10.0).takeIf { it <= 3600.0 }
        } else null

        val liters = intervalSeconds?.let { it * EST_FLOW_LPM / 60.0 }
        val litersMin = intervalSeconds?.let { it * EST_FLOW_MIN_LPM / 60.0 }
        val litersMax = intervalSeconds?.let { it * EST_FLOW_MAX_LPM / 60.0 }

        val previousUsed = previousBytes?.let { bytes -> mirroredValue(bytes.u16leSafe(USAGE_OFFSET), bytes.u16leSafe(USAGE_MIRROR_OFFSET)) }
        val usageDelta = if (used != null && previousUsed != null) used - previousUsed else null
        val hotDelta = if (hotTotal != null && previousLatest != null) hotTotal - previousLatest.fields.getOrElse(7) { hotTotal } else null
        val coldDelta = if (coldTotal != null && previousLatest != null) coldTotal - previousLatest.fields.getOrElse(8) { coldTotal } else null

        val header = current.indexOfAscii("HKSSH001") >= 0
        val notes = buildList {
            if (header) add("HKSSH001 vlasnički potpis potvrđen u EEPROM-u.")
            if (temperatureC != null) add("Temperatura se dekodira kao U16LE / 10 na četiri zrcaljene adrese.")
            if (total != null && used != null && remaining != null && used + remaining == total) {
                add("Brojači used + remaining = total ($used + $remaining = $total). Struktura je potvrđena; fizička jedinica se još kalibrira.")
            }
            if (intervalSeconds != null) add("Od prethodnog očitanja globalni 10 Hz brojač detektirao je %.1f s aktivnog protoka.".format(Locale.US, intervalSeconds))
            if (liters != null) add("Procjena volumena koristi 8,0 L/min; prikazani raspon koristi 6–9 L/min.")
            if (hotDelta != null && hotDelta >= 0) add("Promjena kandidata hot-time: +$hotDelta s.")
            if (coldDelta != null && coldDelta >= 0) add("Promjena kandidata cold-time: +$coldDelta s.")
        }

        return ShowerMetrics(
            temperatureC = temperatureC,
            temperatureRaw = temperatureRaw,
            filterTotalUnits = total,
            filterWarningUsedUnits = warning,
            filterUsedUnits = used,
            filterRemainingUnits = remaining,
            filterRemainingPercent = remainingPercent,
            hotThresholdC = hotThresholdC,
            highThresholdC = highThresholdC,
            coldThresholdC = coldThresholdC,
            currentRecordIndex = latest?.index,
            currentSessionSecondsEstimate = currentSessionSecondsEstimate,
            hotSecondsTotal = hotTotal,
            coldSecondsTotal = coldTotal,
            intervalSeconds = intervalSeconds,
            estimatedIntervalLiters = liters,
            estimatedIntervalLitersMin = litersMin,
            estimatedIntervalLitersMax = litersMax,
            usageUnitsDelta = usageDelta,
            hotSecondsDelta = hotDelta,
            coldSecondsDelta = coldDelta,
            hasHelloKleanHeader = header,
            notes = notes
        )
    }

    fun attachToJson(baseJson: String, metrics: ShowerMetrics): String {
        val root = JSONObject(baseJson)
        root.put("decoded_metrics", metrics.toJson())
        return root.toString(2)
    }

    fun fromJson(json: String?): ShowerMetrics? {
        if (json.isNullOrBlank()) return null
        val obj = runCatching { JSONObject(json).optJSONObject("decoded_metrics") }.getOrNull() ?: return null
        return ShowerMetrics(
            temperatureC = obj.optDoubleOrNull("temperature_c"),
            temperatureRaw = obj.optIntOrNull("temperature_raw_deci_c"),
            filterTotalUnits = obj.optIntOrNull("filter_total_units"),
            filterWarningUsedUnits = obj.optIntOrNull("filter_warning_used_units"),
            filterUsedUnits = obj.optIntOrNull("filter_used_units"),
            filterRemainingUnits = obj.optIntOrNull("filter_remaining_units"),
            filterRemainingPercent = obj.optDoubleOrNull("filter_remaining_percent"),
            hotThresholdC = obj.optDoubleOrNull("threshold_hot_c"),
            highThresholdC = obj.optDoubleOrNull("threshold_high_c"),
            coldThresholdC = obj.optDoubleOrNull("threshold_cold_c"),
            currentRecordIndex = obj.optIntOrNull("current_record_index"),
            currentSessionSecondsEstimate = obj.optDoubleOrNull("current_session_seconds_estimate"),
            hotSecondsTotal = obj.optIntOrNull("hot_seconds_total"),
            coldSecondsTotal = obj.optIntOrNull("cold_seconds_total"),
            intervalSeconds = obj.optDoubleOrNull("interval_seconds"),
            estimatedIntervalLiters = obj.optDoubleOrNull("estimated_interval_liters"),
            estimatedIntervalLitersMin = obj.optDoubleOrNull("estimated_interval_liters_min"),
            estimatedIntervalLitersMax = obj.optDoubleOrNull("estimated_interval_liters_max"),
            usageUnitsDelta = obj.optIntOrNull("usage_units_delta"),
            hotSecondsDelta = obj.optIntOrNull("hot_seconds_delta"),
            coldSecondsDelta = obj.optIntOrNull("cold_seconds_delta"),
            hasHelloKleanHeader = obj.optBoolean("hello_klean_header_detected", false),
            notes = emptyList()
        )
    }

    private fun parseSessionRecords(bytes: ByteArray): List<SessionRecord> {
        val out = mutableListOf<SessionRecord>()
        for (slot in 0 until SESSION_MAX_RECORDS) {
            val offset = SESSION_TABLE_OFFSET + slot * SESSION_RECORD_SIZE
            if (offset + SESSION_RECORD_SIZE > bytes.size) break
            val clock = bytes.u32leSafe(offset) ?: break
            val indexLong = bytes.u32leSafe(offset + 4) ?: break
            if (clock == 0L && indexLong == 0L) continue
            if (indexLong !in 1L..100000L) continue
            val fields = IntArray(10) { i -> bytes.u16leSafe(offset + 8 + i * 2) ?: 0 }
            out += SessionRecord(offset, clock, indexLong.toInt(), fields)
        }
        return out
    }

    private fun mirroredValue(a: Int?, b: Int?): Int? = when {
        a == null -> b
        b == null -> a
        a == b -> a
        else -> min(a, b).takeIf { max(a, b) - min(a, b) <= 1 } ?: a
    }
}

private fun ByteArray.u16leSafe(offset: Int): Int? {
    if (offset < 0 || offset + 1 >= size) return null
    return (this[offset].toInt() and 0xFF) or ((this[offset + 1].toInt() and 0xFF) shl 8)
}

private fun ByteArray.u32leSafe(offset: Int): Long? {
    if (offset < 0 || offset + 3 >= size) return null
    return (this[offset].toLong() and 0xFF) or
        ((this[offset + 1].toLong() and 0xFF) shl 8) or
        ((this[offset + 2].toLong() and 0xFF) shl 16) or
        ((this[offset + 3].toLong() and 0xFF) shl 24)
}

private fun String.hexBytesOrNull(): ByteArray? {
    if (length < 2 || length % 2 != 0) return null
    return runCatching {
        ByteArray(length / 2) { i -> substring(i * 2, i * 2 + 2).toInt(16).toByte() }
    }.getOrNull()
}

private fun ByteArray.indexOfAscii(text: String): Int {
    val needle = text.toByteArray(Charsets.US_ASCII)
    if (needle.isEmpty() || needle.size > size) return -1
    for (i in 0..size - needle.size) {
        var ok = true
        for (j in needle.indices) {
            if (this[i + j] != needle[j]) {
                ok = false
                break
            }
        }
        if (ok) return i
    }
    return -1
}

private fun JSONObject.putNullableLocal(key: String, value: Any?) {
    if (value == null) put(key, JSONObject.NULL) else put(key, value)
}

private fun JSONObject.optIntOrNull(key: String): Int? =
    if (!has(key) || isNull(key)) null else runCatching { getInt(key) }.getOrNull()

private fun JSONObject.optDoubleOrNull(key: String): Double? =
    if (!has(key) || isNull(key)) null else runCatching { getDouble(key) }.getOrNull()
