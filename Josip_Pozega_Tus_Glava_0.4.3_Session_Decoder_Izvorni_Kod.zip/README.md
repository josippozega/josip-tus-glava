# Josip Požega Tuš Glava 0.4.3 — Session Decoder

Android NFC companion aplikacija za read-only dijagnostiku i Smart Dashboard Hello Klean Shower Head+ oznake.

## Što je potvrđeno kontroliranim testovima

Verzija 0.4.3 uklanja pogrešnu pretpostavku iz 0.4.2 da su `0x02CC/0x02CE` vremenski tickovi. Kontrolirani testovi od 30 s i 120 s pokazali su da se stvarno trajanje i volumen nalaze izravno u 28-bajtnom session zapisu koji počinje na `0x0401`.

Session zapis:

- početak tablice: `0x0401`
- duljina jednog zapisa: 28 B (`0x1C`)
- `+0x00`: 32-bitni interni event/clock zapis
- `+0x04`: 32-bitni indeks sessiona
- `+0x0A`: volumen u decilitrima, odnosno `1 count = 0,1 L`
- `+0x0C`: aktivno trajanje protoka u sekundama
- `+0x16`: hot-exposure kandidat
- `+0x18`: cold-exposure kandidat

Najvažnija potvrda:

- u 30-sekundnom testu session volumen porastao je za 36 countova = 3,6 L, a session vrijeme za 30 s; prosječni protok ≈ 7,2 L/min
- u 120-sekundnom testu session volumen porastao je za 142 counta = 14,2 L, a session vrijeme za 119 s; prosječni protok ≈ 7,16 L/min
- raniji zapisi također daju vrlo konzistentan prosječni protok oko 7,0–7,1 L/min

## Novosti u 0.4.3

- trajanje se više ne procjenjuje iz flow tickova; čita se izravno iz session polja `+0x0C`
- volumen se više ne procjenjuje pomoću pretpostavljenih 8 L/min; čita se izravno iz session polja `+0x0A`
- Dashboard prikazuje izmjereni intervalni volumen, trajanje i prosječni protok
- JSON dodaje `current_session_liters_measured`, `current_session_seconds`, `current_session_average_flow_lpm`, `interval_liters_measured`, `interval_average_flow_lpm` i `interval_volume_deciliters_delta`
- `0x02CC/0x02CE` ostaje samo pomoćni dijagnostički brojač i više se ne pretvara ni u sekunde ni u litre
- `0x02C4` ostaje interni event clock
- hot/cold polja ostaju označena kao srednje pouzdana jer aktualni zapis može ostati na 0 dok uređaj ne napravi rollover na sljedeći session
- kada je aktualni hot/cold zapis još otvoren, aplikacija prikazuje kandidat vrijednosti zadnjeg završenog sessiona
- zadržan robust read-only NFC-V reader iz 0.3.1/0.4.x

## Filter / HydraTrack

Struktura `used + remaining = 8000` ostaje potvrđena. Iako ukupni vidljivi session volumen snažno korelira s used brojačem, 0.4.3 ga još ne proglašava izravno litrima jer se pojedinačni kontrolirani intervali ne preslikavaju uvijek 1:1.

## Sigurnost

Aplikacija je read-only. Ne šalje Write, Lock, Format ni Password naredbe. Mailbox sadržaj se ne čita automatski jer čitanje zadnjeg bajta može utjecati na status mailboxa.
