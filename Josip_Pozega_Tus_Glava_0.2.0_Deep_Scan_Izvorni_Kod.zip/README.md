# Josip Požega Tuš Glava — 0.2.0 Deep Scan

Android aplikacija za lokalnu, read-only dijagnostiku NFC oznake na Hello Klean Shower Head+.

## Što je novo u 0.2.0

- standardni NDEF pregled ostaje uključen
- ISO 15693 / NFC-V `Get System Information` (0x2B)
- `Extended Get System Information` (0x3B) kada ga oznaka podržava
- automatsko prepoznavanje broja i veličine memorijskih blokova
- read-only memorijski dump, do sigurnosnog limita 16 KiB
- standardni i extended read-block fallbackovi radi kompatibilnosti
- SHA-256 cijelog očitanog memorijskog dumpa
- broj nepraznih blokova i prvih 256 bajtova za brzu analizu
- potpuni dump nalazi se u JSON-u pod `technology_metadata -> NfcV.memory.dump_hex`

## Sigurnost

Aplikacija ne sadrži naredbe za WRITE, LOCK, FORMAT, PRESENT PASSWORD niti promjene konfiguracije. Za dubinsko očitanje koristi samo ISO 15693 naredbe za čitanje: 0x2B, 0x3B, 0x20, 0x23, 0x30 i 0x33.

Aplikacija nema INTERNET dozvolu.

## Testiranje

1. Isključi vodu i osuši glavu i ruke.
2. Otvori NFC karticu u aplikaciji.
3. Prisloni Z Flip7 uz NFC simbol.
4. Nakon prve vibracije drži telefon potpuno mirno dok očitanje ne završi.
5. Odaberi `Kopiraj zapis` i pošalji JSON na analizu.
