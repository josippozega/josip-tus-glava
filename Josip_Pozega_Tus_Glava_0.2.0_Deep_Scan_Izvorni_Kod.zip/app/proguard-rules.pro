# Za dijagnostičku verziju minifikacija je isključena.
