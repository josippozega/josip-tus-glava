package hr.josippozega.tusglava

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.time.Instant

/**
 * Persistent local history of decoded shower sessions.
 *
 * This database contains only data read from the NFC tag plus the time at which
 * the Android app observed the record. It never writes anything back to the tag.
 */
data class ShowerSessionHistoryEntry(
    val tagId: String,
    val sessionIndex: Int,
    val firstSeenUtc: String,
    val lastSeenUtc: String,
    val liters: Double,
    val durationSeconds: Int,
    val averageFlowLpm: Double?,
    val hotSeconds: Int?,
    val coldSeconds: Int?,
    val finalized: Boolean,
    val rawClock: Long?
)

data class ShowerHistoryStats(
    val sessionCount: Int,
    val totalLiters: Double,
    val totalDurationSeconds: Long,
    val weightedAverageFlowLpm: Double?
)

class ShowerHistoryDatabase(context: Context) : SQLiteOpenHelper(
    context,
    DATABASE_NAME,
    null,
    DATABASE_VERSION
) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE sessions (
                tag_id TEXT NOT NULL,
                session_index INTEGER NOT NULL,
                first_seen_utc TEXT NOT NULL,
                last_seen_utc TEXT NOT NULL,
                volume_dl INTEGER NOT NULL,
                duration_s INTEGER NOT NULL,
                avg_flow_lpm REAL,
                hot_s INTEGER,
                cold_s INTEGER,
                finalized INTEGER NOT NULL DEFAULT 0,
                raw_clock INTEGER,
                PRIMARY KEY(tag_id, session_index)
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX idx_sessions_last_seen ON sessions(last_seen_utc DESC)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 1) onCreate(db)
    }

    fun mergeSnapshot(snapshot: NfcSnapshot): List<ShowerSessionHistoryEntry> {
        val decoded = ShowerMetricsDecoder.decodeSessionRecords(snapshot)
        if (decoded.isEmpty()) return readAll(snapshot.tagIdHex)
        mergeDecoded(snapshot.tagIdHex, snapshot.capturedAt, decoded)
        return readAll(snapshot.tagIdHex)
    }

    fun mergeLatestJson(json: String): List<ShowerSessionHistoryEntry> {
        val imported = ShowerMetricsDecoder.decodeSessionRecordsFromJson(json)
        val tagId = ShowerMetricsDecoder.tagIdFromJson(json) ?: return emptyList()
        val capturedAt = ShowerMetricsDecoder.capturedAtFromJson(json) ?: Instant.now()
        if (imported.isNotEmpty()) mergeDecoded(tagId, capturedAt, imported)
        return readAll(tagId)
    }

    private fun mergeDecoded(tagId: String, capturedAt: Instant, records: List<DecodedShowerSession>) {
        if (tagId.isBlank() || records.isEmpty()) return
        val maxIndex = records.maxOf { it.index }
        val now = capturedAt.toString()
        val db = writableDatabase
        db.beginTransaction()
        try {
            records.forEach { record ->
                val existingFirstSeen = db.rawQuery(
                    "SELECT first_seen_utc FROM sessions WHERE tag_id=? AND session_index=?",
                    arrayOf(tagId, record.index.toString())
                ).use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else null }

                val finalized = record.index < maxIndex ||
                    ((record.hotSeconds ?: 0) > 0 || (record.coldSeconds ?: 0) > 0)

                val values = ContentValues().apply {
                    put("tag_id", tagId)
                    put("session_index", record.index)
                    put("first_seen_utc", existingFirstSeen ?: now)
                    put("last_seen_utc", now)
                    put("volume_dl", record.volumeDeciliters)
                    put("duration_s", record.durationSeconds)
                    record.averageFlowLpm?.let { put("avg_flow_lpm", it) } ?: putNull("avg_flow_lpm")
                    record.hotSeconds?.let { put("hot_s", it) } ?: putNull("hot_s")
                    record.coldSeconds?.let { put("cold_s", it) } ?: putNull("cold_s")
                    put("finalized", if (finalized) 1 else 0)
                    put("raw_clock", record.clockRaw)
                }
                db.insertWithOnConflict("sessions", null, values, SQLiteDatabase.CONFLICT_REPLACE)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun readAll(tagId: String? = null, limit: Int = 120): List<ShowerSessionHistoryEntry> {
        val where = if (tagId.isNullOrBlank()) null else "tag_id=?"
        val args = if (tagId.isNullOrBlank()) null else arrayOf(tagId)
        return readableDatabase.query(
            "sessions",
            arrayOf(
                "tag_id", "session_index", "first_seen_utc", "last_seen_utc",
                "volume_dl", "duration_s", "avg_flow_lpm", "hot_s", "cold_s",
                "finalized", "raw_clock"
            ),
            where,
            args,
            null,
            null,
            "session_index DESC",
            limit.coerceIn(1, 500).toString()
        ).use { cursor ->
            buildList {
                while (cursor.moveToNext()) {
                    val volumeDl = cursor.getInt(4)
                    val seconds = cursor.getInt(5)
                    add(
                        ShowerSessionHistoryEntry(
                            tagId = cursor.getString(0),
                            sessionIndex = cursor.getInt(1),
                            firstSeenUtc = cursor.getString(2),
                            lastSeenUtc = cursor.getString(3),
                            liters = volumeDl / 10.0,
                            durationSeconds = seconds,
                            averageFlowLpm = if (cursor.isNull(6)) null else cursor.getDouble(6),
                            hotSeconds = if (cursor.isNull(7)) null else cursor.getInt(7),
                            coldSeconds = if (cursor.isNull(8)) null else cursor.getInt(8),
                            finalized = cursor.getInt(9) != 0,
                            rawClock = if (cursor.isNull(10)) null else cursor.getLong(10)
                        )
                    )
                }
            }
        }
    }

    fun stats(entries: List<ShowerSessionHistoryEntry>): ShowerHistoryStats {
        val valid = entries.filter { it.liters >= 0.0 && it.durationSeconds >= 0 }
        val totalLiters = valid.sumOf { it.liters }
        val totalSeconds = valid.sumOf { it.durationSeconds.toLong() }
        val weightedFlow = if (totalSeconds > 0) totalLiters * 60.0 / totalSeconds else null
        return ShowerHistoryStats(valid.size, totalLiters, totalSeconds, weightedFlow)
    }

    fun clearAll() {
        writableDatabase.delete("sessions", null, null)
    }

    companion object {
        private const val DATABASE_NAME = "shower_history.db"
        private const val DATABASE_VERSION = 1
    }
}
