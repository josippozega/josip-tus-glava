# Josip Požega Tuš Glava 1.0.0 — Final

Finalna osobna Android aplikacija za potpuno read-only NFC očitanje i lokalno praćenje Hello Klean Shower Head+.

## Produkcijski potvrđeno
- potpuno read-only NFC-V očitanje EEPROM-a (8192 B)
- Hello Klean vlasnički potpis `HKSSH001`
- tablica sesija: `0x0401 + n × 28 B`
- volumen sesije: polje `+0x0A`, 1 count = 0,1 L
- aktivno trajanje protoka: polje `+0x0C`, sekunde
- prosječni protok: izračun iz dekodiranog volumena i aktivnog trajanja
- indeks sesije
- struktura filter brojača `used + remaining = total`

## 1.0.0 Final
- završno hrvatsko korisničko sučelje
- Smart Dashboard s potvrđenim metrikama
- trajna lokalna SQLite baza dekodiranih zapisa sesija
- automatski uvoz svih vidljivih EEPROM sesija
- povijest tuširanja i zbirna statistika
- interaktivni graf volumena po sesiji s vrijednošću na dodir
- interaktivni graf prosječnog protoka
- jasne oznake aktualne i završene sesije
- CSV izvoz povijesti
- kontrolirano brisanje lokalne povijesti uz potvrdu
- eksperimentalni toplinski i hot/cold kandidati skriveni su u naprednom sklopivom dijelu
- NFC Forensics ostaje zaseban napredni read-only ekran
- Postavke s informacijama o jedinicama, lokalnoj pohrani, NFC statusu i privatnosti

## Sigurnost
Aplikacija ne šalje Write, Lock, Format ni Password naredbe i ne mijenja NFC oznaku. Podaci povijesti spremaju se samo lokalno na Android uređaju.
