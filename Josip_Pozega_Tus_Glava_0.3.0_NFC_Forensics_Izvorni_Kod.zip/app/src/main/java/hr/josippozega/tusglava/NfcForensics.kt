package hr.josippozega.tusglava

import org.json.JSONArray
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

private const val NFC_BLOCK_SIZE = 4
private const val MAX_DIFF_RANGES = 16
private const val MAX_HISTORY_SCANS = 12

data class DiffRange(
    val start: Int,
    val endInclusive: Int,
    val oldHex: String,
    val newHex: String,
    val interpretation: String
) {
    val length: Int get() = endInclusive - start + 1
}

data class NfcForensicsReport(
    val hasPrevious: Boolean,
    val previousCapturedAt: String?,
    val changedBytes: Int,
    val changedBlocks: Int,
    val ranges: List<DiffRange>,
    val hkHeaderOffset: Int?,
    val asciiTokens: List<String>,
    val knownValueHints: List<String>,
    val vccPresent: Boolean?,
    val mailboxEnabled: Boolean?,
    val mailboxLengthBytes: Int?,
    val mailboxState: String?,
    val notes: List<String>
) {
    fun summaryText(): String = when {
        !hasPrevious -> "Bazno očitanje spremljeno. Napravi još jedno očitanje nakon kontroliranog tuširanja."
        changedBytes == 0 -> "Nema promjena u 8192 B EEPROM memorije između zadnja dva očitanja."
        else -> "Promijenjeno je $changedBytes bajtova u $changedBlocks memorijskih blokova."
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("comparison_available", hasPrevious)
        if (previousCapturedAt == null) put("previous_captured_at_utc", JSONObject.NULL)
        else put("previous_captured_at_utc", previousCapturedAt)
        put("changed_bytes", changedBytes)
        put("changed_blocks", changedBlocks)
        put("hkssh001_offset", hkHeaderOffset ?: JSONObject.NULL)
        put("ascii_tokens", JSONArray(asciiTokens))
        put("known_value_hints", JSONArray(knownValueHints))
        put("vcc_present", vccPresent ?: JSONObject.NULL)
        put("mailbox_enabled", mailboxEnabled ?: JSONObject.NULL)
        put("mailbox_length_bytes", mailboxLengthBytes ?: JSONObject.NULL)
        put("mailbox_state", mailboxState ?: JSONObject.NULL)
        put("notes", JSONArray(notes))
        put("changed_ranges", JSONArray().apply {
            ranges.forEach { range ->
                put(JSONObject().apply {
                    put("start_offset_decimal", range.start)
                    put("end_offset_decimal", range.endInclusive)
                    put("start_offset_hex", "0x%04X".format(Locale.US, range.start))
                    put("end_offset_hex", "0x%04X".format(Locale.US, range.endInclusive))
                    put("length", range.length)
                    put("old_hex", range.oldHex)
                    put("new_hex", range.newHex)
                    put("interpretation", range.interpretation)
                })
            }
        })
    }
}

object NfcForensics {
    fun analyze(previousJson: String?, snapshot: NfcSnapshot): NfcForensicsReport {
        val currentHex = snapshot.metadata["NfcV.memory.dump_hex"].orEmpty()
        val current = currentHex.hexToBytesOrNull()
        val previousRoot = previousJson?.let { runCatching { JSONObject(it) }.getOrNull() }
        val previousHex = previousRoot
            ?.optJSONObject("technology_metadata")
            ?.optString("NfcV.memory.dump_hex")
            .orEmpty()
        val previous = previousHex.hexToBytesOrNull()
        val previousTag = previousRoot?.optJSONObject("tag")?.optString("id_hex")
        val sameTag = !previousTag.isNullOrBlank() && previousTag == snapshot.tagIdHex
        val comparable = sameTag && current != null && previous != null && current.size == previous.size

        val ranges = if (comparable) diffRanges(previous!!, current!!, MAX_DIFF_RANGES) else emptyList()
        val changedIndices = if (comparable) current!!.indices.filter { current[it] != previous!![it] } else emptyList()
        val changedBlocks = changedIndices.map { it / NFC_BLOCK_SIZE }.toSet().size

        val hkHeader = current?.indexOfSubsequence("HKSSH001".toByteArray(StandardCharsets.US_ASCII))
            ?.takeIf { it >= 0 }
        val tokens = current?.extractAsciiTokens().orEmpty()
            .filter { token -> token.length >= 5 && (token.any(Char::isLetter) || token.all(Char::isDigit)) }
            .distinct()
            .take(20)

        val hints = current?.let(::findKnownValues).orEmpty()
        val vcc = snapshot.metadata["ST25DV.EH_CTRL_Dyn.VCC_ON"]?.toBooleanStrictOrNull()
        val mbEnabled = snapshot.metadata["ST25DV.MB_CTRL_Dyn.MB_EN"]?.toBooleanStrictOrNull()
        val mbLength = snapshot.metadata["ST25DV.mailbox.length_bytes"]?.toIntOrNull()
        val mbState = snapshot.metadata["ST25DV.mailbox.state"]

        val notes = buildList {
            if (hkHeader != null) add("Pronađen Hello Klean vlasnički potpis HKSSH001 na adresi 0x%04X.".format(Locale.US, hkHeader))
            if (vcc == true) add("ST25DV prijavljuje VCC_ON=1: host elektronika je napajana tijekom očitanja.")
            if (vcc == false) add("ST25DV prijavljuje VCC_ON=0: host elektronika nije bila napajana tijekom očitanja.")
            if (mbEnabled == true) add("FTM mailbox je uključen; sadržaj mailboxa namjerno nije čitan jer čitanje zadnjeg bajta može promijeniti status mailboxa.")
            if (mbEnabled == false) add("FTM mailbox trenutačno nije uključen.")
            if (!comparable) add("Ovo očitanje postaje baza za sljedeću usporedbu iste NFC oznake.")
            if (comparable && changedIndices.isEmpty()) add("EEPROM dump je bit-po-bit identičan prethodnom očitanju.")
        }

        return NfcForensicsReport(
            hasPrevious = comparable,
            previousCapturedAt = if (comparable) previousRoot?.optString("captured_at_utc") else null,
            changedBytes = changedIndices.size,
            changedBlocks = changedBlocks,
            ranges = ranges,
            hkHeaderOffset = hkHeader,
            asciiTokens = tokens,
            knownValueHints = hints,
            vccPresent = vcc,
            mailboxEnabled = mbEnabled,
            mailboxLengthBytes = mbLength,
            mailboxState = mbState,
            notes = notes
        )
    }

    fun attachToJson(baseJson: String, report: NfcForensicsReport, historyCount: Int): String {
        val root = JSONObject(baseJson)
        root.put("forensics", report.toJson().apply {
            put("history_scan_count", historyCount)
        })
        return root.toString(2)
    }

    private fun diffRanges(old: ByteArray, new: ByteArray, maxRanges: Int): List<DiffRange> {
        val result = mutableListOf<DiffRange>()
        var i = 0
        while (i < new.size && result.size < maxRanges) {
            if (old[i] == new[i]) {
                i++
                continue
            }
            val start = i
            var end = i
            while (end + 1 < new.size && old[end + 1] != new[end + 1] && end - start < 31) end++
            val oldSlice = old.copyOfRange(start, end + 1)
            val newSlice = new.copyOfRange(start, end + 1)
            result += DiffRange(
                start = start,
                endInclusive = end,
                oldHex = oldSlice.toHexLocal(),
                newHex = newSlice.toHexLocal(),
                interpretation = interpretChange(oldSlice, newSlice)
            )
            i = end + 1
        }
        return result
    }

    private fun interpretChange(old: ByteArray, new: ByteArray): String {
        val parts = mutableListOf<String>()
        if (new.size == 1) {
            parts += "U8 ${old[0].u8()} → ${new[0].u8()}"
        }
        if (new.size == 2) {
            val o = old.u16le(0)
            val n = new.u16le(0)
            parts += "U16LE $o → $n"
            if (o in 100..600 || n in 100..600) parts += "÷10: %.1f → %.1f °C?".format(Locale.US, o / 10.0, n / 10.0)
        }
        if (new.size == 4) {
            val o = old.u32le(0)
            val n = new.u32le(0)
            parts += "U32LE $o → $n"
            val od = epochHint(o)
            val nd = epochHint(n)
            if (od != null || nd != null) parts += "vrijeme ${od ?: "?"} → ${nd ?: "?"}"
        }
        return parts.joinToString("; ").ifBlank { "promjena sirovih bajtova" }
    }

    private fun findKnownValues(bytes: ByteArray): List<String> {
        val wanted = linkedMapOf(420 to "42,0 °C kandidat", 450 to "45,0 °C kandidat", 250 to "25,0 °C kandidat", 8000 to "8000 kandidat", 6400 to "6400 kandidat")
        val hits = mutableListOf<String>()
        for (i in 0 until bytes.size - 1) {
            val value = bytes.u16le(i)
            wanted[value]?.let { label ->
                hits += "0x%04X: U16LE=%d (%s)".format(Locale.US, i, value, label)
            }
        }
        return hits.take(24)
    }

    private fun epochHint(value: Long): String? {
        if (value !in 946684800L..4102444800L) return null
        return runCatching {
            DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss", Locale("hr", "HR"))
                .withZone(ZoneId.of("UTC"))
                .format(Instant.ofEpochSecond(value)) + " UTC"
        }.getOrNull()
    }

    private fun ByteArray.extractAsciiTokens(): List<String> {
        val result = mutableListOf<String>()
        val builder = StringBuilder()
        fun flush() {
            if (builder.length >= 4) result += builder.toString()
            builder.setLength(0)
        }
        forEach { b ->
            val c = b.u8()
            if (c in 32..126) builder.append(c.toChar()) else flush()
        }
        flush()
        return result
    }

    private fun ByteArray.indexOfSubsequence(needle: ByteArray): Int {
        if (needle.isEmpty() || needle.size > size) return -1
        outer@ for (i in 0..size - needle.size) {
            for (j in needle.indices) if (this[i + j] != needle[j]) continue@outer
            return i
        }
        return -1
    }

    private fun ByteArray.u16le(offset: Int): Int =
        (this[offset].u8()) or (this[offset + 1].u8() shl 8)

    private fun ByteArray.u32le(offset: Int): Long =
        (this[offset].u8().toLong()) or
            (this[offset + 1].u8().toLong() shl 8) or
            (this[offset + 2].u8().toLong() shl 16) or
            (this[offset + 3].u8().toLong() shl 24)

    private fun Byte.u8(): Int = toInt() and 0xFF
    private fun ByteArray.toHexLocal(): String = joinToString("") { "%02X".format(Locale.US, it.u8()) }

    private fun String.hexToBytesOrNull(): ByteArray? {
        if (isBlank() || length % 2 != 0) return null
        return runCatching {
            ByteArray(length / 2) { index -> substring(index * 2, index * 2 + 2).toInt(16).toByte() }
        }.getOrNull()
    }
}

object ScanHistoryCodec {
    fun append(existing: String?, json: String): Pair<String, Int> {
        val items = mutableListOf<String>()
        if (!existing.isNullOrBlank()) {
            runCatching { JSONArray(existing) }.getOrNull()?.let { array ->
                for (i in 0 until array.length()) items += array.optString(i)
            }
        }
        items += json
        val kept = items.takeLast(MAX_HISTORY_SCANS)
        val array = JSONArray()
        kept.forEach { array.put(it) }
        return array.toString() to kept.size
    }
}
