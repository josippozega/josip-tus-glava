# Josip Požega Tuš Glava 0.4.2 — Flow Timing Calibration Fix

Android NFC companion aplikacija za read-only dijagnostiku i Smart Dashboard Hello Klean Shower Head+ oznake.

## Najvažnije novosti u 0.4.2

- uklonjeno pogrešno tumačenje adrese `0x02C4` kao 10 Hz mjerača trajanja
- `0x02C4` se sada čuva samo kao interni event clock / dijagnostička vrijednost
- trajanje protoka računa se iz zrcaljenih flow-tick brojača `0x02CC` i `0x02CE`
- uvedena kalibracija `1 tick = 0,4 s`, dobivena kontroliranim testom od točno 60 s (`1600 → 1750`, odnosno 150 tickova = 60,0 s)
- session zapis dodatno koristi polje 1 kao neovisni flow-duration brojač; novi zapis #5 dao je 151 tick = 60,4 s
- kada se globalni i session brojač razlikuju najviše tri ticka, aplikacija ih smatra međusobno potvrđenima
- `interval_seconds` više ne pokazuje lažnih 437,1 s za jednominutni test
- procjena litara ponovno se računa iz kalibriranog trajanja protoka uz središnju procjenu 8 L/min i raspon 6–9 L/min
- kada nastane novi session zapis, `hot_seconds_delta` i `cold_seconds_delta` uzimaju vrijednosti novog zapisa umjesto `null`
- dodani dijagnostički JSON ključevi: `event_clock_raw`, `flow_ticks_raw`, `flow_ticks_delta`, `session_flow_ticks_total`, `session_flow_ticks_delta`, `flow_seconds_per_tick` i `timing_basis`
- Smart Dashboard prikazuje i procijenjeno trajanje zadnje session sesije
- zadržan robust read-only NFC-V reader iz 0.3.1/0.4.x

## Trenutačno dekodirane vrijednosti

- zadnja spremljena temperatura: četiri zrcaljena U16LE polja, vrijednost / 10 °C
- firmware pragovi: 25,0 °C, 42,0 °C i 45,0 °C
- filter struktura: used + remaining = 8000 internih jedinica
- session indeks i session tablica od `0x0401`
- hot/cold session polja
- trajanje protoka iz flow tickova, kalibrirano kontroliranim 60-sekundnim testom
- procijenjeni volumen vode iz trajanja i protoka 6–9 L/min

## Sigurnost

Aplikacija je read-only. Ne šalje Write, Lock, Format ni Password naredbe. Mailbox sadržaj se ne čita automatski jer čitanje zadnjeg bajta može utjecati na status mailboxa.

## Napomena o procjeni litara

Vrijeme protoka sada ima znatno jaču eksperimentalnu potvrdu. Litri su i dalje procjena jer nemamo neovisno volumetrijsko mjerenje stvarnog protoka konkretne instalacije.
