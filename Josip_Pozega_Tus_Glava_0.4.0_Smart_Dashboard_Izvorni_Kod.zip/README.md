# Josip Požega Tuš Glava 0.4.0 — Smart Dashboard

Neovisna, read-only Android aplikacija za Hello Klean Shower Head+ NFC telemetriju.

## Najvažnije novosti u 0.4.0

- novi Smart Dashboard koji pretvara 8192 B EEPROM dump u čitljive metrike
- temperatura vode dekodira se iz četiri zrcaljena U16LE polja kao vrijednost / 10 °C
- prikaz internog filter total / used / remaining brojača i preostalog postotka
- firmware pragovi: cold kandidat, SmartHeat 42 °C, viši temperaturni prag i filter warning
- dekodiranje aktivnog session zapisa iz tablice koja počinje na 0x0400
- kandidat za hot-time i cold-exposure s delta prikazom između dva očitanja
- interni timer koristi se za izračun aktivnog protoka između očitanja
- procjena volumena vode iz trajanja protoka: središnje 8 L/min, raspon 6–9 L/min
- JSON sada sadrži `decoded_metrics` uz puni forenzički dump
- aplikacija pri ponovnom pokretanju učitava zadnji spremljeni Smart Dashboard
- UI jasno označava što je potvrđeno, što srednje pouzdano, a što procjena
- uklonjena je pogrešna pretpostavka da su 32-bitni interni brojači Unix timestampovi

## Potvrđeno dosadašnjim kontroliranim testovima

- EEPROM: 8192 B, 2048 blokova × 4 B
- vlasnički potpis `HKSSH001` na 0x0200
- temperatura: zrcaljena polja oko 0x0298, U16LE / 10
- SmartHeat konfiguracijski prag: 420 = 42,0 °C
- filter struktura: `used + remaining = total`, pri čemu je total 8000
- robust NFC reader 16→8→4→2→1 blokova, do 3 pokušaja

## Još se kalibrira

- fizička jedinica internog HydraTrack brojača
- točna semantika svih 10 polja session zapisa
- hot/cold session polja imaju snažnu, ali još ne konačnu potvrdu
- litri su trenutačno procjena prema vremenu protoka, ne izravno očitan volumen

## Sigurnost

Aplikacija je read-only. Ne koristi Write, Lock, Format, Password Present niti druge naredbe koje mijenjaju stanje NFC oznake. Mailbox sadržaj se namjerno ne čita automatski jer čitanje zadnjeg bajta može promijeniti mailbox status.

Aplikacija nema INTERNET dozvolu i obrađuje podatke lokalno na telefonu.
