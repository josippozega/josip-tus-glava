package hr.josippozega.tusglava

import android.nfc.NdefMessage
import android.nfc.NdefRecord
import android.nfc.Tag
import android.nfc.tech.IsoDep
import android.nfc.tech.MifareClassic
import android.nfc.tech.MifareUltralight
import android.nfc.tech.Ndef
import android.nfc.tech.NdefFormatable
import android.nfc.tech.NfcA
import android.nfc.tech.NfcB
import android.nfc.tech.NfcBarcode
import android.nfc.tech.NfcF
import android.nfc.tech.NfcV
import android.os.Build
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.nio.charset.Charset
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

private const val MAX_DEEP_SCAN_BYTES = 16 * 1024
private const val MULTI_BLOCK_CHUNK = 16
private const val READ_RETRY_COUNT = 3

data class NdefRecordSnapshot(
    val index: Int,
    val tnf: Int,
    val tnfName: String,
    val typeText: String,
    val typeHex: String,
    val idHex: String,
    val payloadLength: Int,
    val payloadHex: String,
    val payloadBase64: String,
    val decodedText: String?,
    val decodedUri: String?,
    val mimeType: String?,
    val printableUtf8: String?
)

data class NfcSnapshot(
    val capturedAt: Instant,
    val tagIdHex: String,
    val tagIdBase64: String,
    val technologies: List<String>,
    val androidTagDescription: String,
    val ndefType: String?,
    val ndefMaxSize: Int?,
    val ndefWritable: Boolean?,
    val ndefMessageBytes: Int?,
    val records: List<NdefRecordSnapshot>,
    val metadata: Map<String, String>,
    val errors: List<String>
) {
    val capturedAtDisplay: String
        get() = DateTimeFormatter.ofPattern("dd.MM.yyyy. HH:mm:ss", Locale("hr", "HR"))
            .withZone(ZoneId.systemDefault())
            .format(capturedAt)

    fun toJsonString(): String {
        val root = JSONObject()
        root.put("format", "josip-pozega-tus-glava-smart-dashboard-v4")
        root.put("captured_at_utc", capturedAt.toString())
        root.put("read_only", true)
        root.put(
            "notice",
            "Aplikacija ne zapisuje, ne formatira i ne zaključava NFC oznaku. Forenzičko očitanje koristi samo standardne i STMicroelectronics read-only NFC-V naredbe za sistemske informacije, EEPROM i status dinamičkih registara."
        )

        root.put("app", JSONObject().apply {
            put("name", "Josip Požega Tuš Glava")
            put("version", BuildConfig.VERSION_NAME)
            put("package", BuildConfig.APPLICATION_ID)
        })

        root.put("android_device", JSONObject().apply {
            put("manufacturer", Build.MANUFACTURER)
            put("brand", Build.BRAND)
            put("model", Build.MODEL)
            put("device", Build.DEVICE)
            put("android_release", Build.VERSION.RELEASE)
            put("sdk_int", Build.VERSION.SDK_INT)
        })

        root.put("tag", JSONObject().apply {
            put("id_hex", tagIdHex)
            put("id_hex_reversed", tagIdHex.hexReversedByByte())
            put("id_base64", tagIdBase64)
            put("technologies", JSONArray(technologies))
            put("android_description", androidTagDescription)
        })

        root.put("ndef", JSONObject().apply {
            putNullable("type", ndefType)
            putNullable("max_size_bytes", ndefMaxSize)
            putNullable("is_writable", ndefWritable)
            putNullable("message_size_bytes", ndefMessageBytes)
            put("record_count", records.size)
        })

        root.put("ndef_records", JSONArray().apply {
            records.forEach { record ->
                put(JSONObject().apply {
                    put("index", record.index)
                    put("tnf", record.tnf)
                    put("tnf_name", record.tnfName)
                    put("type_text", record.typeText)
                    put("type_hex", record.typeHex)
                    put("id_hex", record.idHex)
                    put("payload_length", record.payloadLength)
                    put("payload_hex", record.payloadHex)
                    put("payload_base64", record.payloadBase64)
                    putNullable("decoded_text", record.decodedText)
                    putNullable("decoded_uri", record.decodedUri)
                    putNullable("mime_type", record.mimeType)
                    putNullable("printable_utf8", record.printableUtf8)
                })
            }
        })

        root.put("technology_metadata", JSONObject().apply {
            metadata.forEach { (key, value) -> put(key, value) }
        })
        root.put("errors", JSONArray(errors))

        return root.toString(2)
    }
}

private data class Iso15693SystemInfo(
    val source: String,
    val responseHex: String,
    val infoFlags: Int,
    val uidRawHex: String,
    val dsfid: Int?,
    val afi: Int?,
    val blockCount: Int?,
    val blockSizeBytes: Int?,
    val icReference: Int?,
    val remainingHex: String
)

private fun JSONObject.putNullable(key: String, value: Any?) {
    if (value == null) put(key, JSONObject.NULL) else put(key, value)
}

object NfcDiagnosticReader {
    fun inspect(tag: Tag): NfcSnapshot {
        val metadata = linkedMapOf<String, String>()
        val errors = mutableListOf<String>()
        val tagId = tag.id ?: byteArrayOf()
        val technologyNames = tag.techList
            .map { it.substringAfterLast('.') }
            .sorted()

        inspectTechnologyMetadata(tag, metadata, errors)

        var ndefType: String? = null
        var ndefMaxSize: Int? = null
        var ndefWritable: Boolean? = null
        var ndefMessage: NdefMessage? = null

        val ndef = Ndef.get(tag)
        if (ndef != null) {
            ndefType = ndef.type
            ndefMaxSize = safe("NDEF max size", errors) { ndef.maxSize }
            ndefWritable = safe("NDEF writable", errors) { ndef.isWritable }
            ndefMessage = safe("NDEF read", errors) {
                ndef.connect()
                ndef.ndefMessage ?: ndef.cachedNdefMessage
            }
            safe("NDEF close", errors) {
                if (ndef.isConnected) ndef.close()
            }
        } else {
            metadata["NDEF"] = "NDEF sučelje nije izloženo pri ovom očitanju"
        }

        val records = ndefMessage?.records?.mapIndexed { index, record ->
            inspectRecord(index, record)
        }.orEmpty()

        return NfcSnapshot(
            capturedAt = Instant.now(),
            tagIdHex = tagId.toHex(),
            tagIdBase64 = Base64.encodeToString(tagId, Base64.NO_WRAP),
            technologies = technologyNames,
            androidTagDescription = tag.toString(),
            ndefType = ndefType,
            ndefMaxSize = ndefMaxSize,
            ndefWritable = ndefWritable,
            ndefMessageBytes = ndefMessage?.toByteArray()?.size,
            records = records,
            metadata = metadata,
            errors = errors
        )
    }

    private fun inspectTechnologyMetadata(
        tag: Tag,
        metadata: MutableMap<String, String>,
        errors: MutableList<String>
    ) {
        NfcA.get(tag)?.let { tech ->
            safe("NfcA metadata", errors) {
                metadata["NfcA.atqa_hex"] = tech.atqa.toHex()
                metadata["NfcA.sak"] = tech.sak.toString()
                metadata["NfcA.max_transceive_length"] = tech.maxTransceiveLength.toString()
            }
        }

        NfcB.get(tag)?.let { tech ->
            safe("NfcB metadata", errors) {
                metadata["NfcB.application_data_hex"] = tech.applicationData.toHex()
                metadata["NfcB.protocol_info_hex"] = tech.protocolInfo.toHex()
                metadata["NfcB.max_transceive_length"] = tech.maxTransceiveLength.toString()
            }
        }

        NfcF.get(tag)?.let { tech ->
            safe("NfcF metadata", errors) {
                metadata["NfcF.manufacturer_hex"] = tech.manufacturer.toHex()
                metadata["NfcF.system_code_hex"] = tech.systemCode.toHex()
                metadata["NfcF.max_transceive_length"] = tech.maxTransceiveLength.toString()
            }
        }

        NfcV.get(tag)?.let { tech ->
            safe("NfcV metadata", errors) {
                metadata["NfcV.dsf_id"] = (tech.dsfId.toInt() and 0xFF).toString()
                metadata["NfcV.response_flags"] = (tech.responseFlags.toInt() and 0xFF).toString()
                metadata["NfcV.max_transceive_length"] = tech.maxTransceiveLength.toString()
                metadata["NfcV.tag_id_android_hex"] = tag.id.toHex()
                metadata["NfcV.tag_id_canonical_hex"] = tag.id.reversedArray().toHex()
            }
            inspectNfcVDeepScan(tag, metadata, errors)
        }

        IsoDep.get(tag)?.let { tech ->
            safe("IsoDep metadata", errors) {
                metadata["IsoDep.historical_bytes_hex"] = tech.historicalBytes?.toHex().orEmpty()
                metadata["IsoDep.hi_layer_response_hex"] = tech.hiLayerResponse?.toHex().orEmpty()
                metadata["IsoDep.max_transceive_length"] = tech.maxTransceiveLength.toString()
                metadata["IsoDep.extended_length_apdu"] = tech.isExtendedLengthApduSupported.toString()
            }
        }

        MifareClassic.get(tag)?.let { tech ->
            safe("MifareClassic metadata", errors) {
                metadata["MifareClassic.type"] = tech.type.toString()
                metadata["MifareClassic.size"] = tech.size.toString()
                metadata["MifareClassic.sector_count"] = tech.sectorCount.toString()
                metadata["MifareClassic.block_count"] = tech.blockCount.toString()
            }
        }

        MifareUltralight.get(tag)?.let { tech ->
            safe("MifareUltralight metadata", errors) {
                metadata["MifareUltralight.type"] = tech.type.toString()
                metadata["MifareUltralight.max_transceive_length"] = tech.maxTransceiveLength.toString()
            }
        }

        NfcBarcode.get(tag)?.let { tech ->
            safe("NfcBarcode metadata", errors) {
                metadata["NfcBarcode.type"] = tech.type.toString()
                metadata["NfcBarcode.barcode_hex"] = tech.barcode?.toHex().orEmpty()
            }
        }

        if (NdefFormatable.get(tag) != null) {
            metadata["NdefFormatable"] = "dostupno (nije korišteno; bez zapisivanja)"
        }
    }

    /**
     * Read-only ISO 15693 deep scan. Commands used here never write, lock, format,
     * present passwords or change tag configuration.
     */
    private fun inspectNfcVDeepScan(
        tag: Tag,
        metadata: MutableMap<String, String>,
        errors: MutableList<String>
    ) {
        val tech = NfcV.get(tag) ?: return
        metadata["NfcV.deep_scan.status"] = "pokrenut"
        metadata["NfcV.deep_scan.mode"] = "read-only ISO 15693"
        metadata["NfcV.deep_scan.allowed_commands"] = "2B, 3B, 20, 23, 30, 33, A0, AD, AB (isključivo čitanje)"

        try {
            tech.connect()

            val standardResponse = transceiveChecked(
                tech,
                byteArrayOf(0x02, 0x2B),
                "Get System Information (2B)",
                errors
            )
            if (standardResponse != null) {
                metadata["NfcV.system_info_standard_response_hex"] = standardResponse.toHex()
            }
            val standardInfo = standardResponse?.let { parseStandardSystemInfo(it) }

            val extendedResponse = transceiveChecked(
                tech,
                byteArrayOf(0x02, 0x3B, 0x3F),
                "Extended Get System Information (3B)",
                errors,
                reportUnsupportedAsError = false
            )
            if (extendedResponse != null) {
                metadata["NfcV.system_info_extended_response_hex"] = extendedResponse.toHex()
            }
            val extendedInfo = extendedResponse?.let { parseExtendedSystemInfo(it) }

            val bestInfo = extendedInfo?.takeIf { it.blockCount != null && it.blockSizeBytes != null }
                ?: standardInfo?.takeIf { it.blockCount != null && it.blockSizeBytes != null }
                ?: extendedInfo
                ?: standardInfo

            listOfNotNull(standardInfo, extendedInfo).forEach { info ->
                val prefix = if (info.source == "extended") "NfcV.extended" else "NfcV.standard"
                metadata["$prefix.info_flags_hex"] = "%02X".format(Locale.US, info.infoFlags)
                metadata["$prefix.uid_raw_hex"] = info.uidRawHex
                metadata["$prefix.uid_canonical_hex"] = info.uidRawHex.hexReversedByByte()
                info.dsfid?.let { metadata["$prefix.dsfid"] = it.toString() }
                info.afi?.let { metadata["$prefix.afi"] = it.toString() }
                info.blockCount?.let { metadata["$prefix.block_count"] = it.toString() }
                info.blockSizeBytes?.let { metadata["$prefix.block_size_bytes"] = it.toString() }
                info.icReference?.let { metadata["$prefix.ic_reference_hex"] = "%02X".format(Locale.US, it) }
                if (info.remainingHex.isNotBlank()) metadata["$prefix.remaining_fields_hex"] = info.remainingHex
            }

            val blockCount = bestInfo?.blockCount
            val blockSize = bestInfo?.blockSizeBytes
            if (blockCount == null || blockSize == null || blockCount <= 0 || blockSize <= 0) {
                metadata["NfcV.deep_scan.status"] = "sistemske informacije očitane; veličina memorije nije objavljena"
                return
            }

            val maxBlocksBySafetyCap = (MAX_DEEP_SCAN_BYTES / blockSize).coerceAtLeast(1)
            val blocksToRead = blockCount.coerceAtMost(maxBlocksBySafetyCap)
            val truncated = blocksToRead < blockCount

            metadata["NfcV.memory.block_count_reported"] = blockCount.toString()
            metadata["NfcV.memory.block_size_bytes"] = blockSize.toString()
            metadata["NfcV.memory.reported_bytes"] = (blockCount.toLong() * blockSize).toString()
            metadata["NfcV.memory.scan_limit_bytes"] = MAX_DEEP_SCAN_BYTES.toString()
            metadata["NfcV.memory.scan_truncated"] = truncated.toString()

            val memory = readMemoryReadOnly(
                tech = tech,
                blockCount = blocksToRead,
                blockSize = blockSize,
                errors = errors,
                metadata = metadata
            )

            if (memory != null) {
                metadata["NfcV.memory.blocks_read"] = blocksToRead.toString()
                metadata["NfcV.memory.bytes_read"] = memory.size.toString()
                metadata["NfcV.memory.dump_hex"] = memory.toHex()
                metadata["NfcV.memory.sha256"] = sha256(memory)
                metadata["NfcV.memory.non_zero_blocks"] = countNonZeroBlocks(memory, blockSize).toString()
                metadata["NfcV.memory.first_256_bytes_hex"] = memory.copyOfRange(0, minOf(memory.size, 256)).toHex()
                metadata["NfcV.memory.printable_preview"] = memory.copyOfRange(0, minOf(memory.size, 512))
                    .toMostlyPrintablePreview()
                metadata["NfcV.deep_scan.status"] = if (truncated) {
                    "uspješan (memorija djelomično očitana zbog sigurnosnog limita)"
                } else {
                    "uspješan"
                }
            } else {
                metadata["NfcV.deep_scan.status"] = "sistemske informacije uspješne; memorijski dump nije uspio"
            }

            // Dinamičke ST25 registre čitamo tek nakon EEPROM-a kako dodatni
            // proizvođački upiti ne bi mogli poremetiti dugi memorijski scan.
            inspectSt25ReadOnlyState(tech, metadata, errors)
        } catch (exception: Exception) {
            errors += "NfcV deep scan: ${exception.javaClass.simpleName}: ${exception.message.orEmpty()}"
            metadata["NfcV.deep_scan.status"] = "neuspješan"
        } finally {
            runCatching { if (tech.isConnected) tech.close() }
                .onFailure { errors += "NfcV close: ${it.javaClass.simpleName}: ${it.message.orEmpty()}" }
        }
    }

    private fun inspectSt25ReadOnlyState(
        tech: NfcV,
        metadata: MutableMap<String, String>,
        errors: MutableList<String>
    ) {
        metadata["ST25DV.read_only_probe"] = "A0 Read Configuration, AD Read Dynamic Configuration, AB Read Message Length"
        metadata["ST25DV.mailbox.content_read"] = "false"
        metadata["ST25DV.mailbox.content_read_reason"] = "Namjerno preskočeno: čitanje zadnjeg bajta mailbox poruke može promijeniti HOST_PUT_MSG status."

        val ftm = readSt25Register(tech, 0xA0, 0x0D, "FTM static configuration", errors)
        if (ftm != null) {
            metadata["ST25DV.FTM.raw_hex"] = "%02X".format(Locale.US, ftm)
            metadata["ST25DV.FTM.MB_MODE"] = ((ftm and 0x01) != 0).toString()
            metadata["ST25DV.FTM.MB_WDG"] = ((ftm ushr 1) and 0x07).toString()
        }

        val eh = readSt25Register(tech, 0xAD, 0x02, "EH_CTRL_Dyn", errors)
        if (eh != null) {
            metadata["ST25DV.EH_CTRL_Dyn.raw_hex"] = "%02X".format(Locale.US, eh)
            metadata["ST25DV.EH_CTRL_Dyn.EH_EN"] = ((eh and 0x01) != 0).toString()
            metadata["ST25DV.EH_CTRL_Dyn.EH_ON"] = ((eh and 0x02) != 0).toString()
            metadata["ST25DV.EH_CTRL_Dyn.FIELD_ON"] = ((eh and 0x04) != 0).toString()
            metadata["ST25DV.EH_CTRL_Dyn.VCC_ON"] = ((eh and 0x08) != 0).toString()
        }

        val mb = readSt25Register(tech, 0xAD, 0x0D, "MB_CTRL_Dyn", errors)
        if (mb != null) {
            val mbEn = (mb and 0x01) != 0
            val hostPut = (mb and 0x02) != 0
            val rfPut = (mb and 0x04) != 0
            val hostMiss = (mb and 0x10) != 0
            val rfMiss = (mb and 0x20) != 0
            val hostCurrent = (mb and 0x40) != 0
            val rfCurrent = (mb and 0x80) != 0
            metadata["ST25DV.MB_CTRL_Dyn.raw_hex"] = "%02X".format(Locale.US, mb)
            metadata["ST25DV.MB_CTRL_Dyn.MB_EN"] = mbEn.toString()
            metadata["ST25DV.MB_CTRL_Dyn.HOST_PUT_MSG"] = hostPut.toString()
            metadata["ST25DV.MB_CTRL_Dyn.RF_PUT_MSG"] = rfPut.toString()
            metadata["ST25DV.MB_CTRL_Dyn.HOST_MISS_MSG"] = hostMiss.toString()
            metadata["ST25DV.MB_CTRL_Dyn.RF_MISS_MSG"] = rfMiss.toString()
            metadata["ST25DV.MB_CTRL_Dyn.HOST_CURRENT_MSG"] = hostCurrent.toString()
            metadata["ST25DV.MB_CTRL_Dyn.RF_CURRENT_MSG"] = rfCurrent.toString()
            metadata["ST25DV.mailbox.state"] = when {
                !mbEn -> "disabled"
                hostPut && hostCurrent -> "I2C host message available to RF"
                rfPut && rfCurrent -> "RF message available to I2C host"
                else -> "enabled / no complete message advertised"
            }

            if (mbEn) {
                val lenResponse = runCatching {
                    tech.transceive(byteArrayOf(0x02, 0xAB.toByte(), 0x02))
                }.getOrNull()
                if (lenResponse != null && lenResponse.size >= 2 && (lenResponse[0].toInt() and 0x01) == 0) {
                    val raw = lenResponse[1].toInt() and 0xFF
                    metadata["ST25DV.mailbox.length_raw"] = raw.toString()
                    metadata["ST25DV.mailbox.length_bytes"] = (raw + 1).toString()
                }
            }
        }
    }

    private fun readSt25Register(
        tech: NfcV,
        command: Int,
        registerAddress: Int,
        label: String,
        errors: MutableList<String>
    ): Int? {
        val response = runCatching {
            tech.transceive(
                byteArrayOf(
                    0x02,
                    command.toByte(),
                    0x02, // STMicroelectronics IC manufacturer code
                    registerAddress.toByte()
                )
            )
        }.getOrElse { exception ->
            errors += "$label: ${exception.javaClass.simpleName}: ${exception.message.orEmpty()}"
            return null
        }
        if (response.isEmpty()) return null
        val flags = response[0].toInt() and 0xFF
        if ((flags and 0x01) != 0) {
            val code = response.getOrNull(1)?.toInt()?.and(0xFF)
            if (code !in listOf(0x01, 0x02, 0x03)) {
                errors += "$label: ST25 error ${code?.let { "%02X".format(Locale.US, it) } ?: "??"}"
            }
            return null
        }
        return response.getOrNull(1)?.toInt()?.and(0xFF)
    }

    private fun readMemoryReadOnly(
        tech: NfcV,
        blockCount: Int,
        blockSize: Int,
        errors: MutableList<String>,
        metadata: MutableMap<String, String>
    ): ByteArray? {
        val output = ByteArrayOutputStream(blockCount * blockSize)
        var start = 0
        var selectedMode: String? = null
        var retryEvents = 0
        metadata["NfcV.memory.retry_policy"] = "$READ_RETRY_COUNT pokušaja; adaptivni chunk $MULTI_BLOCK_CHUNK→8→4→2→1 blokova"

        while (start < blockCount) {
            val requested = minOf(MULTI_BLOCK_CHUNK, blockCount - start)
            var actualCount = requested
            var data: ByteArray? = null
            var mode: String? = null

            while (actualCount >= 2 && data == null) {
                if (blockCount > 256 || start > 0xFF) {
                    data = retryRead(tech, READ_RETRY_COUNT) {
                        readExtendedMultiple(tech, start, actualCount, blockSize)
                    }.also { if (it == null) retryEvents++ }
                    mode = if (data != null) "33-extended-read-multiple($actualCount)" else null
                    if (data == null) {
                        data = retryRead(tech, READ_RETRY_COUNT) {
                            readProtocolExtensionMultiple(tech, start, actualCount, blockSize)
                        }.also { if (it == null) retryEvents++ }
                        mode = if (data != null) "23-protocol-extension($actualCount)" else null
                    }
                } else {
                    data = retryRead(tech, READ_RETRY_COUNT) {
                        readStandardMultiple(tech, start, actualCount, blockSize)
                    }.also { if (it == null) retryEvents++ }
                    mode = if (data != null) "23-read-multiple($actualCount)" else null
                    if (data == null) {
                        data = retryRead(tech, READ_RETRY_COUNT) {
                            readExtendedMultiple(tech, start, actualCount, blockSize)
                        }.also { if (it == null) retryEvents++ }
                        mode = if (data != null) "33-extended-read-multiple($actualCount)" else null
                    }
                }

                if (data == null) actualCount /= 2
            }

            if (data == null) {
                actualCount = 1
                data = retryRead(tech, READ_RETRY_COUNT) {
                    if (start <= 0xFF && blockCount <= 256) {
                        readStandardSingle(tech, start, blockSize)
                    } else {
                        readExtendedSingle(tech, start, blockSize)
                            ?: readProtocolExtensionSingle(tech, start, blockSize)
                    }
                }
                mode = if (data != null) "single-block-fallback" else null
            }

            if (data == null) {
                val partial = output.toByteArray()
                metadata["NfcV.memory.blocks_read_before_failure"] = (partial.size / blockSize).toString()
                metadata["NfcV.memory.partial_bytes_read"] = partial.size.toString()
                metadata["NfcV.memory.failure_block"] = start.toString()
                metadata["NfcV.memory.retry_events"] = retryEvents.toString()
                if (partial.isNotEmpty()) metadata["NfcV.memory.partial_sha256"] = sha256(partial)
                errors += "NfcV memory: nije moguće pročitati blok $start nakon $READ_RETRY_COUNT ponovljenih pokušaja"
                return null
            }

            val expected = actualCount * blockSize
            if (data.size != expected) {
                val partial = output.toByteArray()
                metadata["NfcV.memory.blocks_read_before_failure"] = (partial.size / blockSize).toString()
                metadata["NfcV.memory.partial_bytes_read"] = partial.size.toString()
                metadata["NfcV.memory.failure_block"] = start.toString()
                metadata["NfcV.memory.retry_events"] = retryEvents.toString()
                errors += "NfcV memory: neočekivana duljina pri bloku $start (${data.size}, očekivano $expected)"
                return null
            }

            if (selectedMode == null) selectedMode = mode
            else if (selectedMode != mode && !selectedMode.contains(mode.orEmpty())) selectedMode = "$selectedMode + $mode"
            output.write(data)
            start += actualCount
        }

        metadata["NfcV.memory.read_mode"] = selectedMode ?: "nepoznat"
        metadata["NfcV.memory.retry_events"] = retryEvents.toString()
        return output.toByteArray()
    }

    private fun retryRead(tech: NfcV, attempts: Int, action: () -> ByteArray?): ByteArray? {
        repeat(attempts.coerceAtLeast(1)) { attempt ->
            if (!tech.isConnected) return null
            val result = action()
            if (result != null) return result
            if (attempt + 1 < attempts) {
                try {
                    Thread.sleep((6L * (attempt + 1)).coerceAtMost(20L))
                } catch (_: InterruptedException) {
                    Thread.currentThread().interrupt()
                    return null
                }
            }
        }
        return null
    }

    private fun readStandardMultiple(tech: NfcV, start: Int, count: Int, blockSize: Int): ByteArray? {
        if (start !in 0..0xFF || count !in 1..256) return null
        val request = byteArrayOf(
            0x02,
            0x23,
            start.toByte(),
            (count - 1).toByte()
        )
        return extractReadData(runCatching { tech.transceive(request) }.getOrNull(), count * blockSize)
    }

    private fun readExtendedMultiple(tech: NfcV, start: Int, count: Int, blockSize: Int): ByteArray? {
        if (start !in 0..0xFFFF || count !in 1..0x10000) return null
        val minusOne = count - 1
        val request = byteArrayOf(
            0x02,
            0x33,
            (start and 0xFF).toByte(),
            ((start ushr 8) and 0xFF).toByte(),
            (minusOne and 0xFF).toByte(),
            ((minusOne ushr 8) and 0xFF).toByte()
        )
        return extractReadData(runCatching { tech.transceive(request) }.getOrNull(), count * blockSize)
    }

    private fun readProtocolExtensionMultiple(tech: NfcV, start: Int, count: Int, blockSize: Int): ByteArray? {
        if (start !in 0..0xFFFF || count !in 1..256) return null
        val request = byteArrayOf(
            0x0A,
            0x23,
            (start and 0xFF).toByte(),
            ((start ushr 8) and 0xFF).toByte(),
            (count - 1).toByte()
        )
        return extractReadData(runCatching { tech.transceive(request) }.getOrNull(), count * blockSize)
    }

    private fun readStandardSingle(tech: NfcV, block: Int, blockSize: Int): ByteArray? {
        if (block !in 0..0xFF) return null
        return extractReadData(
            runCatching { tech.transceive(byteArrayOf(0x02, 0x20, block.toByte())) }.getOrNull(),
            blockSize
        )
    }

    private fun readExtendedSingle(tech: NfcV, block: Int, blockSize: Int): ByteArray? {
        if (block !in 0..0xFFFF) return null
        return extractReadData(
            runCatching {
                tech.transceive(
                    byteArrayOf(
                        0x02,
                        0x30,
                        (block and 0xFF).toByte(),
                        ((block ushr 8) and 0xFF).toByte()
                    )
                )
            }.getOrNull(),
            blockSize
        )
    }

    private fun readProtocolExtensionSingle(tech: NfcV, block: Int, blockSize: Int): ByteArray? {
        if (block !in 0..0xFFFF) return null
        return extractReadData(
            runCatching {
                tech.transceive(
                    byteArrayOf(
                        0x0A,
                        0x20,
                        (block and 0xFF).toByte(),
                        ((block ushr 8) and 0xFF).toByte()
                    )
                )
            }.getOrNull(),
            blockSize
        )
    }

    private fun extractReadData(response: ByteArray?, expectedBytes: Int): ByteArray? {
        if (response == null || response.isEmpty()) return null
        val responseFlags = response[0].toInt() and 0xFF
        if ((responseFlags and 0x01) != 0) return null
        if (response.size < 1 + expectedBytes) return null
        return response.copyOfRange(1, 1 + expectedBytes)
    }

    private fun transceiveChecked(
        tech: NfcV,
        request: ByteArray,
        label: String,
        errors: MutableList<String>,
        reportUnsupportedAsError: Boolean = true
    ): ByteArray? {
        return try {
            val response = tech.transceive(request)
            if (response.isEmpty()) {
                if (reportUnsupportedAsError) errors += "$label: prazan odgovor"
                null
            } else {
                val flags = response[0].toInt() and 0xFF
                if ((flags and 0x01) != 0) {
                    val code = response.getOrNull(1)?.toInt()?.and(0xFF)
                    if (reportUnsupportedAsError || code !in listOf(0x01, 0x02)) {
                        errors += "$label: ISO15693 error ${code?.let { "%02X".format(Locale.US, it) } ?: "??"}"
                    }
                    null
                } else response
            }
        } catch (exception: Exception) {
            if (reportUnsupportedAsError) {
                errors += "$label: ${exception.javaClass.simpleName}: ${exception.message.orEmpty()}"
            }
            null
        }
    }

    private fun parseStandardSystemInfo(response: ByteArray): Iso15693SystemInfo? {
        if (response.size < 10 || (response[0].toInt() and 0x01) != 0) return null
        val infoFlags = response[1].toInt() and 0xFF
        var cursor = 10
        val uid = response.copyOfRange(2, 10).toHex()
        var dsfid: Int? = null
        var afi: Int? = null
        var blockCount: Int? = null
        var blockSize: Int? = null
        var icRef: Int? = null

        if ((infoFlags and 0x01) != 0 && cursor < response.size) dsfid = response[cursor++].toInt() and 0xFF
        if ((infoFlags and 0x02) != 0 && cursor < response.size) afi = response[cursor++].toInt() and 0xFF
        if ((infoFlags and 0x04) != 0 && cursor + 1 < response.size) {
            blockCount = (response[cursor].toInt() and 0xFF) + 1
            blockSize = (response[cursor + 1].toInt() and 0x1F) + 1
            cursor += 2
        }
        if ((infoFlags and 0x08) != 0 && cursor < response.size) icRef = response[cursor++].toInt() and 0xFF

        return Iso15693SystemInfo(
            source = "standard",
            responseHex = response.toHex(),
            infoFlags = infoFlags,
            uidRawHex = uid,
            dsfid = dsfid,
            afi = afi,
            blockCount = blockCount,
            blockSizeBytes = blockSize,
            icReference = icRef,
            remainingHex = if (cursor < response.size) response.copyOfRange(cursor, response.size).toHex() else ""
        )
    }

    private fun parseExtendedSystemInfo(response: ByteArray): Iso15693SystemInfo? {
        if (response.size < 10 || (response[0].toInt() and 0x01) != 0) return null
        val infoFlags = response[1].toInt() and 0xFF
        var cursor = 10
        val uid = response.copyOfRange(2, 10).toHex()
        var dsfid: Int? = null
        var afi: Int? = null
        var blockCount: Int? = null
        var blockSize: Int? = null
        var icRef: Int? = null

        if ((infoFlags and 0x01) != 0 && cursor < response.size) dsfid = response[cursor++].toInt() and 0xFF
        if ((infoFlags and 0x02) != 0 && cursor < response.size) afi = response[cursor++].toInt() and 0xFF
        if ((infoFlags and 0x04) != 0 && cursor + 2 < response.size) {
            val minusOne = (response[cursor].toInt() and 0xFF) or
                ((response[cursor + 1].toInt() and 0xFF) shl 8)
            blockCount = minusOne + 1
            blockSize = (response[cursor + 2].toInt() and 0x1F) + 1
            cursor += 3
        }
        if ((infoFlags and 0x08) != 0 && cursor < response.size) icRef = response[cursor++].toInt() and 0xFF

        return Iso15693SystemInfo(
            source = "extended",
            responseHex = response.toHex(),
            infoFlags = infoFlags,
            uidRawHex = uid,
            dsfid = dsfid,
            afi = afi,
            blockCount = blockCount,
            blockSizeBytes = blockSize,
            icReference = icRef,
            remainingHex = if (cursor < response.size) response.copyOfRange(cursor, response.size).toHex() else ""
        )
    }

    private fun inspectRecord(index: Int, record: NdefRecord): NdefRecordSnapshot {
        val payload = record.payload ?: byteArrayOf()
        val decodedText = decodeTextRecord(record)
        val decodedUri = runCatching { record.toUri()?.toString() }.getOrNull()
        val mimeType = runCatching { record.toMimeType() }.getOrNull()

        return NdefRecordSnapshot(
            index = index,
            tnf = record.tnf.toInt(),
            tnfName = tnfName(record.tnf),
            typeText = record.type.toSafeUtf8(),
            typeHex = record.type.toHex(),
            idHex = record.id.toHex(),
            payloadLength = payload.size,
            payloadHex = payload.toHex(),
            payloadBase64 = Base64.encodeToString(payload, Base64.NO_WRAP),
            decodedText = decodedText,
            decodedUri = decodedUri,
            mimeType = mimeType,
            printableUtf8 = payload.toMostlyPrintableUtf8()
        )
    }

    private fun decodeTextRecord(record: NdefRecord): String? {
        if (record.tnf != NdefRecord.TNF_WELL_KNOWN ||
            !record.type.contentEquals(NdefRecord.RTD_TEXT)
        ) return null

        val payload = record.payload ?: return null
        if (payload.isEmpty()) return null

        return runCatching {
            val status = payload[0].toInt() and 0xFF
            val languageLength = status and 0x3F
            val textStart = 1 + languageLength
            if (textStart > payload.size) return@runCatching null
            val charset: Charset = if ((status and 0x80) != 0) {
                StandardCharsets.UTF_16
            } else {
                StandardCharsets.UTF_8
            }
            String(payload, textStart, payload.size - textStart, charset)
        }.getOrNull()
    }

    private fun tnfName(tnf: Short): String = when (tnf) {
        NdefRecord.TNF_EMPTY -> "EMPTY"
        NdefRecord.TNF_WELL_KNOWN -> "WELL_KNOWN"
        NdefRecord.TNF_MIME_MEDIA -> "MIME_MEDIA"
        NdefRecord.TNF_ABSOLUTE_URI -> "ABSOLUTE_URI"
        NdefRecord.TNF_EXTERNAL_TYPE -> "EXTERNAL_TYPE"
        NdefRecord.TNF_UNKNOWN -> "UNKNOWN"
        NdefRecord.TNF_UNCHANGED -> "UNCHANGED"
        else -> "TNF_$tnf"
    }

    private inline fun <T> safe(
        operation: String,
        errors: MutableList<String>,
        block: () -> T
    ): T? = try {
        block()
    } catch (exception: Exception) {
        errors += "$operation: ${exception.javaClass.simpleName}: ${exception.message.orEmpty()}"
        null
    }
}

private fun ByteArray?.toHex(): String = this?.joinToString("") { byte ->
    "%02X".format(Locale.US, byte.toInt() and 0xFF)
}.orEmpty()

private fun String.hexReversedByByte(): String {
    if (length % 2 != 0) return this
    return chunked(2).reversed().joinToString("")
}

private fun ByteArray?.toSafeUtf8(): String {
    if (this == null || isEmpty()) return ""
    return runCatching { String(this, StandardCharsets.UTF_8) }
        .getOrDefault("")
        .map { character -> if (character.isISOControl()) '·' else character }
        .joinToString("")
}

private fun ByteArray.toMostlyPrintableUtf8(): String? {
    if (isEmpty()) return null
    val decoded = runCatching { String(this, StandardCharsets.UTF_8) }.getOrNull() ?: return null
    if (decoded.isEmpty()) return null
    val printable = decoded.count { character ->
        !character.isISOControl() || character == '\n' || character == '\r' || character == '\t'
    }
    return if (printable.toDouble() / decoded.length >= 0.80) decoded else null
}

private fun ByteArray.toMostlyPrintablePreview(): String {
    if (isEmpty()) return ""
    return buildString {
        this@toMostlyPrintablePreview.forEach { byte ->
            val value = byte.toInt() and 0xFF
            append(if (value in 32..126) value.toChar() else '·')
        }
    }.trim('·')
}

private fun sha256(data: ByteArray): String = MessageDigest.getInstance("SHA-256")
    .digest(data)
    .toHex()

private fun countNonZeroBlocks(data: ByteArray, blockSize: Int): Int {
    if (blockSize <= 0) return 0
    var count = 0
    var offset = 0
    while (offset < data.size) {
        val end = minOf(offset + blockSize, data.size)
        var nonZero = false
        for (index in offset until end) {
            if (data[index].toInt() != 0) {
                nonZero = true
                break
            }
        }
        if (nonZero) count++
        offset += blockSize
    }
    return count
}
