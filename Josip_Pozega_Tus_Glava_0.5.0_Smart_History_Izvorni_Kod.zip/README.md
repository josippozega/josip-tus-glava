# Josip Požega Tuš Glava 0.5.0 — Smart History

Završna funkcionalna faza osobne Android aplikacije za read-only NFC očitanje Hello Klean Shower Head+.

## Produkcijski potvrđeno
- potpuno read-only NFC-V očitanje EEPROM-a (8192 B)
- Hello Klean vlasnički potpis `HKSSH001`
- session tablica: `0x0401 + n × 28 B`
- session volumen: polje `+0x0A`, 1 count = 0,1 L
- aktivno trajanje protoka: polje `+0x0C`, sekunde
- prosječni protok: izračun iz dekodiranog volumena i aktivnog trajanja
- session indeks
- struktura filter brojača `used + remaining = total`

## 0.5.0
- novi Smart Dashboard bez nepotvrđene temperature kao glavne metrike
- trajna lokalna SQLite baza dekodiranih session zapisa
- automatski import svih vidljivih EEPROM sessiona
- povijest tuširanja i zbirna statistika
- graf volumena po sessionu
- graf prosječnog protoka
- CSV izvoz povijesti
- odvojeni eksperimentalni dio za toplinski kandidat i hot/cold polja
- NFC Forensics ostaje dostupan kao napredni read-only laboratorij

## Sigurnost
Aplikacija ne šalje Write, Lock, Format ni Password naredbe i ne mijenja NFC oznaku.
