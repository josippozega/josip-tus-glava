package hr.josippozega.tusglava

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.AcUnit
import androidx.compose.material.icons.rounded.Analytics
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DataObject
import androidx.compose.material.icons.rounded.DeviceThermostat
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Nfc
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.Water
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

private val Ink = Color(0xFF06131F)
private val DeepSea = Color(0xFF0A2030)
private val Glass = Color(0xC8143042)
private val GlassStrong = Color(0xE61A3C50)
private val Aqua = Color(0xFF68E7EB)
private val Turquoise = Color(0xFF2DD4BF)
private val Sky = Color(0xFF58BFF8)
private val Ice = Color(0xFFC9F9FB)
private val Muted = Color(0xFF9DB5C4)
private val Warm = Color(0xFFFFA36C)
private val Success = Color(0xFF78E7BA)
private val Danger = Color(0xFFFF8E9D)

enum class ScanPhase {
    READY,
    READING,
    SUCCESS,
    ERROR,
    NFC_DISABLED,
    UNSUPPORTED
}

data class NfcUiState(
    val nfcSupported: Boolean = true,
    val nfcEnabled: Boolean = true,
    val phase: ScanPhase = ScanPhase.READY,
    val statusMessage: String = "Spremno za sigurno NFC očitanje",
    val latestSnapshot: NfcSnapshot? = null,
    val latestJson: String? = null,
    val forensicsReport: NfcForensicsReport? = null,
    val metrics: ShowerMetrics? = null,
    val historyCount: Int = 0,
    val sessionHistory: List<ShowerSessionHistoryEntry> = emptyList(),
    val historyStats: ShowerHistoryStats = ShowerHistoryStats(0, 0.0, 0L, null)
)

class MainActivity : ComponentActivity(), NfcAdapter.ReaderCallback {
    private var nfcAdapter: NfcAdapter? = null
    private lateinit var historyDb: ShowerHistoryDatabase
    private var uiState by mutableStateOf(NfcUiState())
    private val reading = AtomicBoolean(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        nfcAdapter = NfcAdapter.getDefaultAdapter(this)
        historyDb = ShowerHistoryDatabase(this)
        restoreSavedDashboard()
        refreshNfcState()

        setContent {
            JosipShowerTheme {
                ShowerApp(
                    state = uiState,
                    onShare = { shareDiagnostic() },
                    onCopy = { copyDiagnostic() },
                    onShareHistory = { shareHistory() },
                    onOpenNfcSettings = { openNfcSettings() }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshNfcState()
        enableReaderMode()
    }

    override fun onPause() {
        nfcAdapter?.disableReaderMode(this)
        super.onPause()
    }

    override fun onTagDiscovered(tag: Tag) {
        if (!reading.compareAndSet(false, true)) return

        runOnUiThread {
            uiState = uiState.copy(
                phase = ScanPhase.READING,
                statusMessage = "Očitavam podatke — ne pomiči telefon"
            )
        }

        try {
            val preferences = getSharedPreferences("nfc_diagnostic", MODE_PRIVATE)
            val previousJson = preferences.getString("latest_complete_json", null)
            val existingHistory = preferences.getString("history_json", null)
            val snapshot = NfcDiagnosticReader.inspect(tag)
            val report = NfcForensics.analyze(previousJson, snapshot)
            val metrics = ShowerMetricsDecoder.decode(previousJson, snapshot)
            val completeDump = snapshot.metadata["NfcV.memory.dump_hex"]?.length == 8192 * 2
            val currentHistoryCount = historyCount(existingHistory)
            val nextHistoryCount = if (completeDump) (currentHistoryCount + 1).coerceAtMost(12) else currentHistoryCount
            val forensicJson = NfcForensics.attachToJson(snapshot.toJsonString(), report, nextHistoryCount)
            val json = ShowerMetricsDecoder.attachToJson(forensicJson, metrics)
            val savedCount = persistLatestDiagnostic(json, completeDump)
            val sessionHistory = if (completeDump) historyDb.mergeSnapshot(snapshot) else historyDb.readAll(snapshot.tagIdHex)
            val historyStats = historyDb.stats(sessionHistory)
            runOnUiThread {
                vibrateSuccess()
                uiState = uiState.copy(
                    phase = ScanPhase.SUCCESS,
                    statusMessage = when {
                        !completeDump -> "Očitanje je nepotpuno — nije spremljeno kao forenzička baza"
                        report.hasPrevious -> "Smart Dashboard ažuriran — usporedba je spremna"
                        else -> "Bazno očitanje spremljeno — Smart Dashboard je spreman"
                    },
                    latestSnapshot = snapshot,
                    latestJson = json,
                    forensicsReport = report,
                    metrics = metrics,
                    historyCount = savedCount,
                    sessionHistory = sessionHistory,
                    historyStats = historyStats
                )
            }
        } catch (exception: Exception) {
            runOnUiThread {
                uiState = uiState.copy(
                    phase = ScanPhase.ERROR,
                    statusMessage = "Očitavanje nije uspjelo: ${exception.message.orEmpty()}"
                )
            }
        } finally {
            reading.set(false)
        }
    }


    private fun restoreSavedDashboard() {
        val preferences = getSharedPreferences("nfc_diagnostic", MODE_PRIVATE)
        val latest = preferences.getString("latest_complete_json", null)
        val history = preferences.getString("history_json", null)
        val sessionHistory = if (!latest.isNullOrBlank()) {
            historyDb.mergeLatestJson(latest)
        } else {
            historyDb.readAll()
        }
        val stats = historyDb.stats(sessionHistory)
        if (!latest.isNullOrBlank()) {
            uiState = uiState.copy(
                phase = ScanPhase.SUCCESS,
                statusMessage = "Učitani su posljednji spremljeni podaci",
                latestJson = latest,
                metrics = ShowerMetricsDecoder.fromJson(latest),
                historyCount = historyCount(history),
                sessionHistory = sessionHistory,
                historyStats = stats
            )
        } else {
            uiState = uiState.copy(sessionHistory = sessionHistory, historyStats = stats)
        }
    }

    private fun refreshNfcState() {
        val adapter = nfcAdapter
        uiState = when {
            adapter == null -> uiState.copy(
                nfcSupported = false,
                nfcEnabled = false,
                phase = ScanPhase.UNSUPPORTED,
                statusMessage = "Ovaj uređaj nema NFC"
            )

            !adapter.isEnabled -> uiState.copy(
                nfcSupported = true,
                nfcEnabled = false,
                phase = ScanPhase.NFC_DISABLED,
                statusMessage = "Uključi NFC za početak očitanja"
            )

            else -> uiState.copy(
                nfcSupported = true,
                nfcEnabled = true,
                phase = if (uiState.latestJson == null) ScanPhase.READY else uiState.phase,
                statusMessage = if (uiState.latestJson == null) {
                    "Spremno za sigurno NFC očitanje"
                } else uiState.statusMessage
            )
        }
    }

    private fun enableReaderMode() {
        val adapter = nfcAdapter ?: return
        if (!adapter.isEnabled) return

        val flags = NfcAdapter.FLAG_READER_NFC_A or
            NfcAdapter.FLAG_READER_NFC_B or
            NfcAdapter.FLAG_READER_NFC_F or
            NfcAdapter.FLAG_READER_NFC_V or
            NfcAdapter.FLAG_READER_NFC_BARCODE or
            NfcAdapter.FLAG_READER_NO_PLATFORM_SOUNDS

        val options = Bundle().apply {
            putInt(NfcAdapter.EXTRA_READER_PRESENCE_CHECK_DELAY, 250)
        }
        adapter.enableReaderMode(this, this, flags, options)
    }

    private fun persistLatestDiagnostic(json: String, completeDump: Boolean): Int {
        val preferences = getSharedPreferences("nfc_diagnostic", MODE_PRIVATE)
        val existingHistory = preferences.getString("history_json", null)
        val (historyJson, count) = if (completeDump) {
            ScanHistoryCodec.append(existingHistory, json)
        } else {
            existingHistory.orEmpty() to historyCount(existingHistory)
        }
        val editor = preferences.edit()
            .putString("latest_json", json)
        if (completeDump) {
            editor.putString("latest_complete_json", json)
            editor.putString("history_json", historyJson)
        }
        editor.apply()

        runCatching {
            val directory = File(filesDir, "nfc-history").apply { mkdirs() }
            val timestamp = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss_SSS", Locale.US)
                .withZone(ZoneId.systemDefault())
                .format(Instant.now())
            File(directory, "scan_$timestamp.json").writeText(json, Charsets.UTF_8)
            directory.listFiles()
                ?.sortedByDescending { it.lastModified() }
                ?.drop(12)
                ?.forEach { it.delete() }
        }
        return count
    }

    private fun historyCount(historyJson: String?): Int {
        if (historyJson.isNullOrBlank()) return 0
        return runCatching { org.json.JSONArray(historyJson).length() }.getOrDefault(0)
    }

    private fun shareDiagnostic() {
        val json = uiState.latestJson ?: run {
            Toast.makeText(this, "Najprije očitaj tuš-glavu.", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val directory = File(cacheDir, "nfc-diagnostics").apply { mkdirs() }
            val capturedAt = uiState.latestSnapshot?.capturedAt ?: Instant.now()
            val timestamp = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss", Locale.US)
                .withZone(ZoneId.systemDefault())
                .format(capturedAt)
            val file = File(directory, "Josip_Pozega_Tus_Glava_NFC_$timestamp.json")
            file.writeText(json, Charsets.UTF_8)
            val uri = FileProvider.getUriForFile(this, "$packageName.files", file)

            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/json"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "NFC dijagnostika — Josip Požega Tuš Glava")
                clipData = ClipData.newRawUri("NFC dijagnostika", uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "Pošalji NFC zapis"))
        } catch (exception: Exception) {
            Toast.makeText(this, "Izvoz nije uspio: ${exception.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun shareHistory() {
        val entries = uiState.sessionHistory
        if (entries.isEmpty()) {
            Toast.makeText(this, "Povijest tuširanja je prazna.", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val directory = File(cacheDir, "nfc-diagnostics").apply { mkdirs() }
            val timestamp = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss", Locale.US)
                .withZone(ZoneId.systemDefault())
                .format(Instant.now())
            val file = File(directory, "Josip_Pozega_Tus_Glava_Povijest_$timestamp.csv")
            val csv = buildString {
                appendLine("session;liters;active_seconds;average_flow_lpm;hot_seconds;cold_seconds;finalized;first_seen_utc;last_seen_utc")
                entries.sortedBy { it.sessionIndex }.forEach { e ->
                    append(e.sessionIndex).append(';')
                    append(String.format(Locale.US, "%.1f", e.liters)).append(';')
                    append(e.durationSeconds).append(';')
                    append(e.averageFlowLpm?.let { String.format(Locale.US, "%.2f", it) } ?: "").append(';')
                    append(e.hotSeconds ?: "").append(';')
                    append(e.coldSeconds ?: "").append(';')
                    append(if (e.finalized) "1" else "0").append(';')
                    append(e.firstSeenUtc).append(';').append(e.lastSeenUtc).appendLine()
                }
            }
            file.writeText(csv, Charsets.UTF_8)
            val uri = FileProvider.getUriForFile(this, "$packageName.files", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/csv"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "Povijest tuširanja — Josip Požega Tuš Glava")
                clipData = ClipData.newRawUri("Povijest tuširanja", uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "Pošalji povijest tuširanja"))
        } catch (exception: Exception) {
            Toast.makeText(this, "Izvoz povijesti nije uspio: ${exception.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun copyDiagnostic() {
        val json = uiState.latestJson ?: run {
            Toast.makeText(this, "Najprije očitaj tuš-glavu.", Toast.LENGTH_SHORT).show()
            return
        }
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("NFC dijagnostika", json))
        Toast.makeText(this, "NFC zapis kopiran.", Toast.LENGTH_SHORT).show()
    }

    private fun openNfcSettings() {
        runCatching { startActivity(Intent(Settings.ACTION_NFC_SETTINGS)) }
            .recoverCatching { startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS)) }
    }

    @Suppress("DEPRECATION")
    private fun vibrateSuccess() {
        val effect = VibrationEffect.createWaveform(longArrayOf(0, 55, 45, 90), -1)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager = getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager
            manager.defaultVibrator.vibrate(effect)
        } else {
            val vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
            vibrator.vibrate(effect)
        }
    }
}

private enum class AppTab(val label: String, val icon: ImageVector) {
    HOME("Početna", Icons.Rounded.Home),
    HISTORY("Povijest", Icons.Rounded.Water),
    INSIGHTS("Uvidi", Icons.Rounded.Analytics),
    NFC("NFC", Icons.Rounded.Nfc),
    SETTINGS("Postavke", Icons.Rounded.Settings)
}

@Composable
private fun JosipShowerTheme(content: @Composable () -> Unit) {
    val colors = darkColorScheme(
        primary = Aqua,
        onPrimary = Ink,
        primaryContainer = Color(0xFF16475A),
        onPrimaryContainer = Ice,
        secondary = Turquoise,
        onSecondary = Ink,
        tertiary = Sky,
        background = Ink,
        onBackground = Color.White,
        surface = DeepSea,
        onSurface = Color.White,
        surfaceVariant = Color(0xFF17384A),
        onSurfaceVariant = Muted,
        error = Danger
    )
    MaterialTheme(colorScheme = colors, content = content)
}

@Composable
private fun ShowerApp(
    state: NfcUiState,
    onShare: () -> Unit,
    onCopy: () -> Unit,
    onShareHistory: () -> Unit,
    onOpenNfcSettings: () -> Unit
) {
    var selectedTab by remember { mutableStateOf(AppTab.HOME) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF06131F), Color(0xFF092434), Color(0xFF06131F))
                )
            )
    ) {
        Box(
            modifier = Modifier
                .size(330.dp)
                .align(Alignment.TopEnd)
                .background(
                    Brush.radialGradient(
                        listOf(Aqua.copy(alpha = 0.12f), Color.Transparent)
                    )
                )
        )

        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                NavigationBar(
                    containerColor = Color(0xF20A1C29),
                    tonalElevation = 0.dp,
                    modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
                ) {
                    AppTab.entries.forEach { tab ->
                        NavigationBarItem(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab },
                            icon = { Icon(tab.icon, contentDescription = tab.label) },
                            label = { Text(tab.label, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Ink,
                                selectedTextColor = Aqua,
                                indicatorColor = Aqua,
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { innerPadding ->
            AnimatedContent(
                targetState = selectedTab,
                label = "main-navigation",
                modifier = Modifier
                    .padding(innerPadding)
                    .fillMaxSize()
            ) { tab ->
                when (tab) {
                    AppTab.HOME -> HomeScreen(
                        state = state,
                        onOpenNfc = { selectedTab = AppTab.NFC },
                        onOpenHistory = { selectedTab = AppTab.HISTORY }
                    )

                    AppTab.HISTORY -> HistoryScreen(state, onShareHistory)
                    AppTab.INSIGHTS -> InsightsScreen(state)
                    AppTab.NFC -> NfcScreen(
                        state = state,
                        onShare = onShare,
                        onCopy = onCopy,
                        onOpenNfcSettings = onOpenNfcSettings
                    )

                    AppTab.SETTINGS -> SettingsScreen(state)
                }
            }
        }
    }
}

@Composable
private fun ScreenHeader(eyebrow: String, title: String, subtitle: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.statusBars)
            .padding(top = 22.dp, start = 22.dp, end = 22.dp, bottom = 18.dp)
    ) {
        Text(
            text = eyebrow.uppercase(Locale("hr", "HR")),
            color = Aqua,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = title,
            color = Color.White,
            fontSize = 30.sp,
            lineHeight = 34.sp,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(Modifier.height(7.dp))
        Text(
            text = subtitle,
            color = Muted,
            fontSize = 14.sp,
            lineHeight = 20.sp
        )
    }
}

@Composable
private fun HomeScreen(
    state: NfcUiState,
    onOpenNfc: () -> Unit,
    onOpenHistory: () -> Unit
) {
    val metrics = state.metrics
    val hasData = state.latestJson != null
    val filterPercent = metrics?.filterRemainingPercent
    val latestSession = state.sessionHistory.firstOrNull()
    val stats = state.historyStats

    LazyColumn(
        contentPadding = PaddingValues(bottom = 28.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            ScreenHeader(
                eyebrow = "Smart Dashboard 0.5.0",
                title = "Josip Požega\nTuš Glava",
                subtitle = "Lokalni pregled stvarno dekodiranih session zapisa: voda, aktivno trajanje, prosječni protok i stanje filter brojača."
            )
        }

        item {
            GlassCard(
                modifier = Modifier.padding(horizontal = 18.dp),
                strong = true
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    FilterOrb(hasScan = hasData)
                    Spacer(Modifier.width(18.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        StatusPill(
                            text = when {
                                metrics?.hasHelloKleanHeader == true -> "HELLO KLEAN DEKODIRAN"
                                hasData -> "NFC OČITAN"
                                else -> "ČEKA PRVO OČITANJE"
                            },
                            color = if (hasData) Success else Sky
                        )
                        Spacer(Modifier.height(12.dp))
                        Text(
                            text = filterPercent?.let { "Filter ${formatPercent(it)}" } ?: "Stanje filtera",
                            color = Color.White,
                            fontSize = 23.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(Modifier.height(5.dp))
                        Text(
                            text = when {
                                metrics?.filterRemainingUnits != null && metrics.filterTotalUnits != null ->
                                    "${metrics.filterRemainingUnits} / ${metrics.filterTotalUnits} internih jedinica preostalo"
                                hasData -> "Filter brojač nije dostupan u ovom očitanju."
                                else -> "Prvo NFC očitanje učitava podatke iz tuš-glave."
                            },
                            color = Muted,
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )
                    }
                }

                filterPercent?.let { percent ->
                    Spacer(Modifier.height(18.dp))
                    LinearProgressIndicator(
                        progress = { (percent / 100.0).toFloat().coerceIn(0f, 1f) },
                        color = Success,
                        trackColor = Color.White.copy(alpha = 0.08f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(CircleShape)
                    )
                }

                Spacer(Modifier.height(22.dp))
                Button(
                    onClick = onOpenNfc,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Aqua, contentColor = Ink),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Icon(Icons.Rounded.Nfc, contentDescription = null)
                    Spacer(Modifier.width(9.dp))
                    Text(
                        if (!hasData) "Pokreni NFC očitanje" else "Ažuriraj podatke",
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        item {
            SectionLabel("ZADNJI SESSION", Modifier.padding(start = 22.dp, top = 26.dp, bottom = 12.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.padding(horizontal = 18.dp)
            ) {
                MiniMetric(
                    icon = Icons.Rounded.Water,
                    label = "Izmjerena voda",
                    value = latestSession?.let { "${formatOne(it.liters)} L" } ?: "—",
                    accent = Sky,
                    modifier = Modifier.weight(1f)
                )
                MiniMetric(
                    icon = Icons.Rounded.Timer,
                    label = "Aktivni protok",
                    value = latestSession?.let { formatDuration(it.durationSeconds.toDouble()) } ?: "—",
                    accent = Turquoise,
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(Modifier.height(12.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.padding(horizontal = 18.dp)
            ) {
                MiniMetric(
                    icon = Icons.Rounded.Speed,
                    label = "Prosječni protok",
                    value = latestSession?.averageFlowLpm?.let { "${formatOne(it)} L/min" } ?: "—",
                    accent = Ice,
                    modifier = Modifier.weight(1f)
                )
                MiniMetric(
                    icon = Icons.Rounded.DataObject,
                    label = "Session zapis",
                    value = latestSession?.let { "#${it.sessionIndex}" } ?: "—",
                    accent = Aqua,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            GlassCard(modifier = Modifier.padding(horizontal = 18.dp, vertical = 24.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Analytics, contentDescription = null, tint = Sky, modifier = Modifier.size(28.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Lokalna povijest", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                        Spacer(Modifier.height(3.dp))
                        Text(
                            "${stats.sessionCount} sessiona · ${formatOne(stats.totalLiters)} L · ${formatDurationLong(stats.totalDurationSeconds)}",
                            color = Muted,
                            fontSize = 12.sp
                        )
                    }
                }
                if (state.sessionHistory.size >= 2) {
                    Spacer(Modifier.height(18.dp))
                    SparklineChart(
                        values = state.sessionHistory.sortedBy { it.sessionIndex }.takeLast(10).map { it.liters },
                        accent = Sky,
                        valueSuffix = "L"
                    )
                }
                Spacer(Modifier.height(16.dp))
                FilledTonalButton(
                    onClick = onOpenHistory,
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = Color.White.copy(alpha = 0.08f),
                        contentColor = Ice
                    ),
                    shape = RoundedCornerShape(17.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Rounded.Analytics, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Otvori povijest i grafove")
                }
            }
        }

        item {
            GlassCard(modifier = Modifier.padding(horizontal = 18.dp, vertical = 2.dp)) {
                Row(verticalAlignment = Alignment.Top) {
                    Icon(Icons.Rounded.Shield, contentDescription = null, tint = Success)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Produkcijski potvrđeno", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(5.dp))
                        Text(
                            "Session volumen (+0x0A, 0,1 L), aktivno trajanje (+0x0C), prosječni protok, indeks sessiona i struktura filter brojača koriste se u glavnom sučelju. Toplinski i hot/cold kandidati ostaju u eksperimentalnom dijelu.",
                            color = Muted,
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HistoryScreen(state: NfcUiState, onShareHistory: () -> Unit) {
    val entries = state.sessionHistory
    val stats = state.historyStats
    val chronological = entries.sortedBy { it.sessionIndex }

    LazyColumn(contentPadding = PaddingValues(bottom = 30.dp), modifier = Modifier.fillMaxSize()) {
        item {
            ScreenHeader(
                eyebrow = "Lokalna baza",
                title = "Povijest tuširanja",
                subtitle = "Session zapisi spremaju se lokalno na uređaju. Vrijeme prikazano uz zapis znači kada ga je aplikacija očitala, ne nužno vrijeme početka tuširanja."
            )
        }

        if (entries.isEmpty()) {
            item {
                GlassCard(modifier = Modifier.padding(horizontal = 18.dp), strong = true) {
                    Text("Još nema spremljenih sessiona", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    Text("Napravi potpuno NFC očitanje. 0.5.0 će automatski uvesti sve valjane session zapise iz EEPROM tablice.", color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
                }
            }
        } else {
            item {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.padding(horizontal = 18.dp)
                ) {
                    MiniMetric(Icons.Rounded.DataObject, "Spremljeno sessiona", stats.sessionCount.toString(), Aqua, Modifier.weight(1f))
                    MiniMetric(Icons.Rounded.Water, "Ukupno vode", "${formatOne(stats.totalLiters)} L", Sky, Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.padding(horizontal = 18.dp)
                ) {
                    MiniMetric(Icons.Rounded.Timer, "Aktivno vrijeme", formatDurationLong(stats.totalDurationSeconds), Turquoise, Modifier.weight(1f))
                    MiniMetric(Icons.Rounded.Speed, "Prosj. protok", stats.weightedAverageFlowLpm?.let { "${formatOne(it)} L/min" } ?: "—", Ice, Modifier.weight(1f))
                }
            }

            item {
                SectionLabel("POSLJEDNJIH ${minOf(10, entries.size)} SESSIONA", Modifier.padding(start = 22.dp, top = 26.dp, bottom = 12.dp))
                GlassCard(modifier = Modifier.padding(horizontal = 18.dp)) {
                    Text("Volumen po sessionu", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(12.dp))
                    SparklineChart(chronological.takeLast(10).map { it.liters }, Sky, "L")
                    Spacer(Modifier.height(18.dp))
                    Text("Prosječni protok", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(12.dp))
                    SparklineChart(chronological.takeLast(10).mapNotNull { it.averageFlowLpm }, Turquoise, "L/min")
                }
            }

            item {
                FilledTonalButton(
                    onClick = onShareHistory,
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = Color.White.copy(alpha = 0.08f),
                        contentColor = Ice
                    ),
                    shape = RoundedCornerShape(17.dp),
                    modifier = Modifier
                        .padding(horizontal = 18.dp, vertical = 18.dp)
                        .fillMaxWidth()
                ) {
                    Icon(Icons.Rounded.Share, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Izvezi povijest kao CSV")
                }
            }

            item {
                SectionLabel("SESSION ZAPISI", Modifier.padding(start = 22.dp, top = 4.dp, bottom = 10.dp))
            }

            entries.take(30).forEach { entry ->
                item(key = "session-${entry.sessionIndex}") {
                    SessionHistoryCard(entry)
                }
            }
        }
    }
}

@Composable
private fun SessionHistoryCard(entry: ShowerSessionHistoryEntry) {
    GlassCard(modifier = Modifier.padding(horizontal = 18.dp, vertical = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(15.dp))
                    .background((if (entry.finalized) Success else Aqua).copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Text("#${entry.sessionIndex}", color = if (entry.finalized) Success else Aqua, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) {
                Text("${formatOne(entry.liters)} L · ${formatDuration(entry.durationSeconds.toDouble())}", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(3.dp))
                Text(
                    buildString {
                        entry.averageFlowLpm?.let { append("${formatOne(it)} L/min") }
                        if (isNotEmpty()) append(" · ")
                        append(if (entry.finalized) "završen" else "aktualan")
                    },
                    color = Muted,
                    fontSize = 12.sp
                )
                Spacer(Modifier.height(3.dp))
                Text("zadnje očitano ${formatObservedAt(entry.lastSeenUtc)}", color = Muted.copy(alpha = 0.8f), fontSize = 10.sp)
            }
        }
        if (entry.finalized && ((entry.hotSeconds ?: 0) > 0 || (entry.coldSeconds ?: 0) > 0)) {
            Spacer(Modifier.height(12.dp))
            Text(
                "Eksperimentalno hot/cold: ${entry.hotSeconds ?: 0} s / ${entry.coldSeconds ?: 0} s",
                color = Warm,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
private fun SparklineChart(values: List<Double>, accent: Color, valueSuffix: String) {
    if (values.isEmpty()) {
        Text("Nema dovoljno podataka za graf.", color = Muted, fontSize = 12.sp)
        return
    }
    val minValue = values.minOrNull() ?: 0.0
    val maxValue = values.maxOrNull() ?: minValue
    val span = (maxValue - minValue).takeIf { it > 0.0001 } ?: 1.0

    Column {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(116.dp)
        ) {
            if (values.size == 1) {
                drawCircle(accent, radius = 5.dp.toPx(), center = Offset(size.width / 2f, size.height / 2f))
            } else {
                val stepX = size.width / (values.size - 1).toFloat()
                fun point(index: Int): Offset {
                    val normalized = ((values[index] - minValue) / span).toFloat().coerceIn(0f, 1f)
                    val y = size.height - (normalized * size.height * 0.78f + size.height * 0.11f)
                    return Offset(index * stepX, y)
                }
                for (i in 0 until values.lastIndex) {
                    drawLine(
                        color = accent,
                        start = point(i),
                        end = point(i + 1),
                        strokeWidth = 3.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                }
                values.indices.forEach { i ->
                    drawCircle(accent, radius = 3.5.dp.toPx(), center = point(i))
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("min ${formatOne(minValue)} $valueSuffix", color = Muted, fontSize = 10.sp)
            Text("max ${formatOne(maxValue)} $valueSuffix", color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun InsightsScreen(state: NfcUiState) {
    val metrics = state.metrics
    val stats = state.historyStats
    LazyColumn(contentPadding = PaddingValues(bottom = 30.dp), modifier = Modifier.fillMaxSize()) {
        item {
            ScreenHeader(
                eyebrow = "Dekodirana telemetrija",
                title = "Uvidi tuširanja",
                subtitle = "0.5.0 odvaja produkcijski potvrđena polja od eksperimentalnih kandidata. Glavni Dashboard više ne prikazuje nepotvrđenu temperaturu kao činjenicu."
            )
        }

        item {
            GlassCard(modifier = Modifier.padding(horizontal = 18.dp), strong = true) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.WaterDrop, contentDescription = null, tint = Aqua, modifier = Modifier.size(34.dp))
                    Spacer(Modifier.width(13.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Filter", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            metrics?.filterRemainingPercent?.let { "${formatPercent(it)} preostalo" } ?: "Čeka NFC očitanje",
                            color = if (metrics?.filterRemainingPercent != null) Success else Muted,
                            fontSize = 26.sp,
                            fontWeight = FontWeight.Bold
                        )
                        metrics?.let { m ->
                            if (m.filterUsedUnits != null && m.filterRemainingUnits != null && m.filterTotalUnits != null) {
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    "Interni brojač: ${m.filterUsedUnits} iskorišteno + ${m.filterRemainingUnits} preostalo = ${m.filterTotalUnits}",
                                    color = Muted,
                                    fontSize = 12.sp,
                                    lineHeight = 17.sp
                                )
                            }
                        }
                    }
                }
                Spacer(Modifier.height(14.dp))
                ConfidenceLine("Struktura brojača", "visoka", Success)
                ConfidenceLine("Fizička jedinica filter brojača", "nije proglašena litrama", Warm)
            }
        }

        item {
            SectionLabel("POTVRĐENE SESSION METRIKE", Modifier.padding(start = 22.dp, top = 26.dp, bottom = 12.dp))
            InsightRow(
                Icons.Rounded.Water,
                "Volumen aktualnog sessiona",
                "Izravno polje +0x0A; 1 count = 0,1 L",
                Sky,
                metrics?.currentSessionLitersMeasured?.let { "${formatOne(it)} L" } ?: "—"
            )
            InsightRow(
                Icons.Rounded.Timer,
                "Aktivno trajanje",
                "Izravno polje +0x0C; predstavlja sekunde aktivnog protoka koje je uređaj zabilježio",
                Turquoise,
                metrics?.currentSessionSecondsEstimate?.let(::formatDuration) ?: "—"
            )
            InsightRow(
                Icons.Rounded.Speed,
                "Prosječni protok",
                "Računa se iz izmjerenog volumena i aktivnog trajanja",
                Ice,
                metrics?.currentSessionAverageFlowLpm?.let { "${formatOne(it)} L/min" } ?: "—"
            )
            InsightRow(
                Icons.Rounded.DataObject,
                "Session indeks",
                "Monotono raste u vidljivoj EEPROM session tablici",
                Aqua,
                metrics?.currentRecordIndex?.let { "#$it" } ?: "—"
            )
        }

        item {
            if (metrics?.intervalLitersMeasured != null && metrics.intervalSeconds != null) {
                GlassCard(modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp)) {
                    Text("Promjena od prethodnog očitanja", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Session zapis daje ${formatOne(metrics.intervalLitersMeasured)} L u ${formatDuration(metrics.intervalSeconds)}. " +
                            (metrics.intervalAverageFlowLpm?.let { "Prosječni protok je ${formatOne(it)} L/min." } ?: ""),
                        color = Muted,
                        fontSize = 13.sp,
                        lineHeight = 19.sp
                    )
                }
            }
        }

        item {
            SectionLabel("LOKALNA STATISTIKA", Modifier.padding(start = 22.dp, top = 20.dp, bottom = 12.dp))
            GlassCard(modifier = Modifier.padding(horizontal = 18.dp)) {
                DiagnosticLine("Spremljeni sessioni", stats.sessionCount.toString())
                DiagnosticLine("Ukupno dekodirane vode", "${formatOne(stats.totalLiters)} L")
                DiagnosticLine("Ukupno aktivno vrijeme", formatDurationLong(stats.totalDurationSeconds))
                DiagnosticLine("Ponderirani prosj. protok", stats.weightedAverageFlowLpm?.let { "${formatOne(it)} L/min" } ?: "—")
            }
        }

        item {
            SectionLabel("EKSPERIMENTALNO", Modifier.padding(start = 22.dp, top = 22.dp, bottom = 12.dp))
            GlassCard(modifier = Modifier.padding(horizontal = 18.dp)) {
                Row(verticalAlignment = Alignment.Top) {
                    Icon(Icons.Rounded.Info, contentDescription = null, tint = Warm)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Toplinski kandidat nije potvrđena temperatura vode", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(5.dp))
                        Text(
                            metrics?.temperatureRaw?.let { "Sirova vrijednost: $it; matematički U16LE/10 = ${formatOne(it / 10.0)}. Tijekom testova vrijednost se ponašala kumulativno, pa je 0.5.0 ne koristi na glavnom Dashboardu." }
                                ?: "Toplinski kandidat trenutno nije dostupan.",
                            color = Muted,
                            fontSize = 13.sp,
                            lineHeight = 19.sp
                        )
                    }
                }
                Spacer(Modifier.height(14.dp))
                DiagnosticLine("Cold prag kandidat", metrics?.coldThresholdC?.let { "${formatOne(it)} °C" } ?: "—")
                DiagnosticLine("Hot prag kandidat", metrics?.hotThresholdC?.let { "${formatOne(it)} °C" } ?: "—")
                DiagnosticLine("Viši prag kandidat", metrics?.highThresholdC?.let { "${formatOne(it)} °C" } ?: "—")
                DiagnosticLine("Hot/cold zadnji završeni", if (metrics?.lastFinalizedHotSeconds != null || metrics?.lastFinalizedColdSeconds != null) "${metrics.lastFinalizedHotSeconds ?: 0} s / ${metrics.lastFinalizedColdSeconds ?: 0} s" else "—")
            }
        }

        item {
            state.forensicsReport?.let { report ->
                SectionLabel("NFC FORENZIKA", Modifier.padding(start = 22.dp, top = 24.dp, bottom = 12.dp))
                GlassCard(modifier = Modifier.padding(horizontal = 18.dp), strong = true) {
                    Text(report.summaryText(), color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(14.dp))
                    DiagnosticLine("Spremljena očitanja", state.historyCount.toString())
                    DiagnosticLine("Promijenjeni bajtovi", if (report.hasPrevious) report.changedBytes.toString() else "bazno očitanje")
                    DiagnosticLine("Promijenjeni blokovi", if (report.hasPrevious) report.changedBlocks.toString() else "—")
                    DiagnosticLine("HKSSH001", report.hkHeaderOffset?.let { "0x%04X".format(Locale.US, it) } ?: "nije pronađen")
                    DiagnosticLine("VCC host elektronike", report.vccPresent?.let { if (it) "UKLJUČEN" else "ISKLJUČEN" } ?: "nepoznato")
                    DiagnosticLine("FTM mailbox", report.mailboxState ?: "nije dostupan")
                }
            }
        }

        item {
            GlassCard(modifier = Modifier.padding(horizontal = 18.dp, vertical = 22.dp)) {
                Text("Pouzdanost 0.5.0", color = Color.White, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                ConfidenceLine("Volumen sessiona", "visoka — 0,1 L/count", Success)
                ConfidenceLine("Aktivno trajanje", "visoka — izravne sekunde", Success)
                ConfidenceLine("Prosječni protok", "visoka — izvedeno iz potvrđenih polja", Success)
                ConfidenceLine("Filter used/remaining struktura", "visoka", Success)
                ConfidenceLine("Toplinski kandidat", "eksperimentalno", Warm)
                ConfidenceLine("Hot / cold polja", "eksperimentalno", Warm)
            }
        }
    }
}

@Composable
private fun NfcScreen(
    state: NfcUiState,
    onShare: () -> Unit,
    onCopy: () -> Unit,
    onOpenNfcSettings: () -> Unit
) {
    LazyColumn(contentPadding = PaddingValues(bottom = 30.dp), modifier = Modifier.fillMaxSize()) {
        item {
            ScreenHeader(
                eyebrow = "NFC laboratorij",
                title = "NFC Forensics",
                subtitle = "Read-only analiza: 8192 B EEPROM, ST25DV dinamički status i automatska usporedba s prethodnim očitanjem."
            )
        }
        item {
            GlassCard(modifier = Modifier.padding(horizontal = 18.dp), strong = true) {
                NfcPulse(state.phase)
                Spacer(Modifier.height(18.dp))
                Text(
                    text = when (state.phase) {
                        ScanPhase.READY -> "Prisloni telefon"
                        ScanPhase.READING -> "Očitavam…"
                        ScanPhase.SUCCESS -> "Očitavanje završeno"
                        ScanPhase.ERROR -> "Pokušaj ponovno"
                        ScanPhase.NFC_DISABLED -> "NFC je isključen"
                        ScanPhase.UNSUPPORTED -> "NFC nije dostupan"
                    },
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
                Spacer(Modifier.height(7.dp))
                Text(
                    state.statusMessage,
                    color = Muted,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )

                if (state.phase == ScanPhase.NFC_DISABLED) {
                    Spacer(Modifier.height(18.dp))
                    Button(
                        onClick = onOpenNfcSettings,
                        colors = ButtonDefaults.buttonColors(containerColor = Aqua, contentColor = Ink),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.AutoMirrored.Rounded.OpenInNew, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Otvori NFC postavke", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            SectionLabel("KONTROLIRANI EKSPERIMENT", Modifier.padding(start = 22.dp, top = 26.dp, bottom = 12.dp))
            StepCard("1", "Bazno očitanje", "S ugašenom vodom napravi prvo očitanje. Ono postaje referentna baza.")
            StepCard("2", "Kontrolirano korištenje", "Pusti vodu poznato vrijeme i zapamti što si napravio — npr. 60 s hladnije vode bez promjene drugih uvjeta.")
            StepCard("3", "Ponovno očitanje", "Odmah nakon toga ponovno prisloni telefon. Aplikacija automatski uspoređuje svih 8192 bajta.")
            StepCard("4", "Kopiraj forenzički zapis", "Pošalji JSON s changed_ranges, ST25DV statusom i memorijskim dumpom kako bismo mapirali telemetriju.")
        }

        item {
            AnimatedVisibility(visible = state.latestSnapshot != null) {
                state.latestSnapshot?.let { snapshot ->
                    Column {
                        SectionLabel("REZULTAT", Modifier.padding(start = 22.dp, top = 22.dp, bottom = 12.dp))
                        GlassCard(modifier = Modifier.padding(horizontal = 18.dp)) {
                            DiagnosticLine("Vrijeme", snapshot.capturedAtDisplay)
                            DiagnosticLine("ID oznake", snapshot.tagIdHex.ifBlank { "nije izložen" })
                            DiagnosticLine("Tehnologije", snapshot.technologies.joinToString(", "))
                            DiagnosticLine("NDEF zapisi", snapshot.records.size.toString())
                            DiagnosticLine("Deep Scan", snapshot.metadata["NfcV.deep_scan.status"] ?: "nije dostupan")
                            snapshot.metadata["NfcV.memory.blocks_read"]?.let { DiagnosticLine("Blokovi memorije", it) }
                            snapshot.metadata["NfcV.memory.bytes_read"]?.let { DiagnosticLine("Očitano bajtova", it) }
                            DiagnosticLine("Povijest", "${state.historyCount} očitanja")
                            snapshot.metadata["ST25DV.EH_CTRL_Dyn.VCC_ON"]?.let { DiagnosticLine("VCC_ON", it) }
                            snapshot.metadata["ST25DV.MB_CTRL_Dyn.raw_hex"]?.let { DiagnosticLine("MB_CTRL_Dyn", "0x$it") }
                            snapshot.metadata["ST25DV.mailbox.length_bytes"]?.let { DiagnosticLine("Mailbox", "$it B") }
                            state.forensicsReport?.let { report ->
                                DiagnosticLine("Promjene vs. prethodno", if (report.hasPrevious) "${report.changedBytes} B / ${report.changedBlocks} blokova" else "bazno očitanje")
                            }
                            DiagnosticLine("Pogreške", snapshot.errors.size.toString())

                            Spacer(Modifier.height(18.dp))
                            Button(
                                onClick = onShare,
                                colors = ButtonDefaults.buttonColors(containerColor = Aqua, contentColor = Ink),
                                shape = RoundedCornerShape(17.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp)
                            ) {
                                Icon(Icons.Rounded.Share, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text("Pošalji dijagnostički zapis", fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.height(10.dp))
                            FilledTonalButton(
                                onClick = onCopy,
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = Color.White.copy(alpha = 0.08f),
                                    contentColor = Ice
                                ),
                                shape = RoundedCornerShape(17.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Rounded.ContentCopy, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text("Kopiraj forenzički zapis")
                            }
                        }
                    }
                }
            }
        }

        item {
            GlassCard(modifier = Modifier.padding(horizontal = 18.dp, vertical = 24.dp)) {
                Row(verticalAlignment = Alignment.Top) {
                    Icon(Icons.Rounded.Lock, contentDescription = null, tint = Success)
                    Spacer(Modifier.width(12.dp))
                    Text(
                        "Read-only zaštita je trajno uključena. Verzija 0.5.0 ne šalje Write/Lock/Password naredbe. Mailbox sadržaj se namjerno ne čita automatski jer čitanje zadnjeg bajta može promijeniti njegov status; čitaju se samo sigurni statusni registri.",
                        color = Muted,
                        fontSize = 13.sp,
                        lineHeight = 19.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(state: NfcUiState) {
    LazyColumn(contentPadding = PaddingValues(bottom = 30.dp), modifier = Modifier.fillMaxSize()) {
        item {
            ScreenHeader(
                eyebrow = "Postavke",
                title = "Tvoja aplikacija",
                subtitle = "Dizajnirana za Samsung Galaxy Z Flip7 i Hello Klean Shower Head+."
            )
        }
        item {
            GlassCard(modifier = Modifier.padding(horizontal = 18.dp), strong = true) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(62.dp)
                            .clip(RoundedCornerShape(19.dp))
                            .background(Brush.linearGradient(listOf(Aqua, Sky))),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Rounded.WaterDrop,
                            contentDescription = null,
                            tint = Ink,
                            modifier = Modifier.size(34.dp)
                        )
                    }
                    Spacer(Modifier.width(15.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Josip Požega Tuš Glava", color = Color.White, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        Text("Verzija ${BuildConfig.VERSION_NAME}", color = Muted, fontSize = 13.sp)
                    }
                }
            }
        }
        item {
            SectionLabel("SIGURNOST I PRIVATNOST", Modifier.padding(start = 22.dp, top = 26.dp, bottom = 12.dp))
            SettingRow(Icons.Rounded.Lock, "Samo čitanje", "Trajno uključeno", Success)
            SettingRow(Icons.Rounded.Shield, "Internetski pristup", "Nije zatražen", Aqua)
            SettingRow(
                Icons.Rounded.Nfc,
                "NFC status",
                when {
                    !state.nfcSupported -> "Nije podržan"
                    state.nfcEnabled -> "Uključen"
                    else -> "Isključen"
                },
                if (state.nfcEnabled) Success else Danger
            )
            SettingRow(Icons.Rounded.DataObject, "Lokalna baza sessiona", "${state.sessionHistory.size} zapisa", Sky)
        }
        item {
            SectionLabel("O APLIKACIJI", Modifier.padding(start = 22.dp, top = 22.dp, bottom = 12.dp))
            GlassCard(modifier = Modifier.padding(horizontal = 18.dp)) {
                Row(verticalAlignment = Alignment.Top) {
                    Icon(Icons.Rounded.Info, contentDescription = null, tint = Sky)
                    Spacer(Modifier.width(12.dp))
                    Text(
                        "Ovo je neovisna osobna Android aplikacija izrađena za Josipa Požegu. Nije službena aplikacija društva Hello Klean i ne koristi njihov vizualni identitet.",
                        color = Muted,
                        fontSize = 13.sp,
                        lineHeight = 19.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun GlassCard(
    modifier: Modifier = Modifier,
    strong: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        color = if (strong) GlassStrong else Glass,
        shape = RoundedCornerShape(28.dp),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
        shadowElevation = if (strong) 10.dp else 0.dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(20.dp), content = content)
    }
}

@Composable
private fun FilterOrb(hasScan: Boolean) {
    Box(
        modifier = Modifier
            .size(96.dp)
            .clip(CircleShape)
            .background(
                Brush.radialGradient(
                    listOf(
                        (if (hasScan) Success else Sky).copy(alpha = 0.28f),
                        Color.Transparent
                    )
                )
            )
            .border(1.dp, (if (hasScan) Success else Sky).copy(alpha = 0.5f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            if (hasScan) Icons.Rounded.CheckCircle else Icons.Rounded.WaterDrop,
            contentDescription = null,
            tint = if (hasScan) Success else Aqua,
            modifier = Modifier.size(42.dp)
        )
    }
}

@Composable
private fun StatusPill(text: String, color: Color) {
    Surface(
        color = color.copy(alpha = 0.12f),
        shape = RoundedCornerShape(50),
        border = BorderStroke(1.dp, color.copy(alpha = 0.35f))
    ) {
        Text(
            text,
            color = color,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
        )
    }
}

@Composable
private fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        color = Muted,
        fontSize = 10.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.6.sp,
        modifier = modifier
    )
}

@Composable
private fun MiniMetric(
    icon: ImageVector,
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = Glass,
        shape = RoundedCornerShape(23.dp),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.07f)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Box(
                modifier = Modifier
                    .size(37.dp)
                    .clip(CircleShape)
                    .background(accent.copy(alpha = 0.13f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.height(15.dp))
            Text(value, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(
                label,
                color = Muted,
                fontSize = 11.sp,
                lineHeight = 15.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun InsightRow(icon: ImageVector, title: String, subtitle: String, accent: Color, value: String = "—") {
    GlassCard(modifier = Modifier.padding(horizontal = 18.dp, vertical = 5.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(15.dp))
                    .background(accent.copy(alpha = 0.13f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(23.dp))
            }
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(3.dp))
                Text(subtitle, color = Muted, fontSize = 12.sp, lineHeight = 17.sp)
            }
            Text(value, color = accent, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun NfcPulse(phase: ScanPhase) {
    val infinite = rememberInfiniteTransition(label = "nfc-pulse")
    val scale by infinite.animateFloat(
        initialValue = 0.82f,
        targetValue = 1.18f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse-scale"
    )
    val activeColor = when (phase) {
        ScanPhase.SUCCESS -> Success
        ScanPhase.ERROR, ScanPhase.NFC_DISABLED, ScanPhase.UNSUPPORTED -> Danger
        else -> Aqua
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(178.dp),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(132.dp)
                .scale(if (phase == ScanPhase.READING || phase == ScanPhase.READY) scale else 1f)
                .alpha(0.34f)
                .clip(CircleShape)
                .background(activeColor.copy(alpha = 0.18f))
                .border(1.dp, activeColor.copy(alpha = 0.45f), CircleShape)
        )
        Box(
            modifier = Modifier
                .size(96.dp)
                .clip(CircleShape)
                .background(Brush.radialGradient(listOf(activeColor.copy(alpha = 0.28f), DeepSea)))
                .border(1.dp, activeColor.copy(alpha = 0.65f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            when (phase) {
                ScanPhase.READING -> CircularProgressIndicator(
                    color = activeColor,
                    strokeWidth = 3.dp,
                    modifier = Modifier.size(44.dp)
                )
                ScanPhase.SUCCESS -> Icon(Icons.Rounded.CheckCircle, null, tint = activeColor, modifier = Modifier.size(47.dp))
                ScanPhase.ERROR, ScanPhase.NFC_DISABLED, ScanPhase.UNSUPPORTED -> Icon(
                    Icons.Rounded.ErrorOutline,
                    null,
                    tint = activeColor,
                    modifier = Modifier.size(47.dp)
                )
                else -> Icon(Icons.Rounded.Nfc, null, tint = activeColor, modifier = Modifier.size(47.dp))
            }
        }
    }
}

@Composable
private fun StepCard(number: String, title: String, body: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(Aqua.copy(alpha = 0.13f))
                .border(1.dp, Aqua.copy(alpha = 0.35f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(number, color = Aqua, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
        Spacer(Modifier.width(13.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Spacer(Modifier.height(4.dp))
            Text(body, color = Muted, fontSize = 13.sp, lineHeight = 18.sp)
        }
    }
}

@Composable
private fun DiagnosticLine(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 7.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(label, color = Muted, fontSize = 12.sp, modifier = Modifier.width(105.dp))
        Text(
            value,
            color = Color.White,
            fontSize = 12.sp,
            lineHeight = 17.sp,
            modifier = Modifier.weight(1f),
            maxLines = 3,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun ConfidenceLine(label: String, value: String, accent: Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
        Surface(
            color = accent.copy(alpha = 0.12f),
            shape = RoundedCornerShape(50),
            border = BorderStroke(1.dp, accent.copy(alpha = 0.24f))
        ) {
            Text(
                value.uppercase(Locale("hr", "HR")),
                color = accent,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.7.sp,
                modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)
            )
        }
    }
}

private fun formatOne(value: Double): String = String.format(Locale("hr", "HR"), "%.1f", value)

private fun formatPercent(value: Double): String = String.format(Locale("hr", "HR"), "%.1f %%", value)

private fun formatDuration(seconds: Double): String {
    val total = seconds.coerceAtLeast(0.0).toInt()
    val minutes = total / 60
    val secs = total % 60
    return if (minutes > 0) "%d:%02d min".format(Locale.US, minutes, secs) else "$secs s"
}

private fun formatDurationLong(seconds: Long): String {
    val safe = seconds.coerceAtLeast(0L)
    val hours = safe / 3600
    val minutes = (safe % 3600) / 60
    val secs = safe % 60
    return when {
        hours > 0 -> "%d h %02d min".format(Locale.US, hours, minutes)
        minutes > 0 -> "%d min %02d s".format(Locale.US, minutes, secs)
        else -> "$secs s"
    }
}

private fun formatObservedAt(isoUtc: String): String = runCatching {
    DateTimeFormatter.ofPattern("dd.MM. HH:mm", Locale("hr", "HR"))
        .withZone(ZoneId.systemDefault())
        .format(Instant.parse(isoUtc))
}.getOrDefault("—")

@Composable
private fun SettingRow(icon: ImageVector, title: String, value: String, accent: Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 22.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(14.dp))
        Text(title, color = Color.White, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Surface(color = accent.copy(alpha = 0.11f), shape = RoundedCornerShape(50)) {
            Text(
                value,
                color = accent,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
            )
        }
    }
}
