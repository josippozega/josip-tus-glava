package hr.josippozega.tusglava

import org.json.JSONObject
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

private const val FILTER_TOTAL_OFFSET = 0x0256
private const val FILTER_WARNING_OFFSET = 0x0258
private const val TEMP_HIGH_OFFSET = 0x025A
private const val TEMP_HOT_OFFSET = 0x025C
private const val TEMP_COLD_OFFSET = 0x025E

private const val USAGE_OFFSET = 0x0290
private const val USAGE_MIRROR_OFFSET = 0x0292
private const val REMAINING_OFFSET = 0x0294
private const val REMAINING_MIRROR_OFFSET = 0x0296
private val TEMPERATURE_OFFSETS = intArrayOf(0x0298, 0x029C, 0x02A0, 0x02A4)

private const val SESSION_TABLE_OFFSET = 0x0401
private const val SESSION_RECORD_SIZE = 28
private const val SESSION_MAX_RECORDS = 32

// Session record schema established from controlled 30 s / 60 s / 120 s experiments.
// fields[0] = +0x08 unknown/reserved
// fields[1] = +0x0A volume in decilitres (0.1 L/count)
// fields[2] = +0x0C active flow duration in seconds
// fields[7] = +0x16 hot-exposure candidate
// fields[8] = +0x18 cold-exposure candidate
private const val SESSION_VOLUME_DL_FIELD = 1
private const val SESSION_DURATION_SECONDS_FIELD = 2
private const val SESSION_HOT_FIELD = 7
private const val SESSION_COLD_FIELD = 8

// Diagnostic-only counters. They are deliberately not used for time/volume in 0.5.0.
private const val EVENT_CLOCK_OFFSET = 0x02C4
private const val AUX_COUNTER_OFFSET = 0x02CC
private const val AUX_COUNTER_MIRROR_OFFSET = 0x02CE

/**
 * User-facing decode of the proprietary Hello Klean EEPROM layout.
 *
 * 0.5.0 keeps duration and volume on direct session-record fields validated by
 * controlled 30 s / 60 s / 120 s experiments. Thermal and hot/cold fields remain
 * explicitly experimental until their semantics are independently confirmed.
 */
data class ShowerMetrics(
    val temperatureC: Double?,
    val temperatureRaw: Int?,
    val filterTotalUnits: Int?,
    val filterWarningUsedUnits: Int?,
    val filterUsedUnits: Int?,
    val filterRemainingUnits: Int?,
    val filterRemainingPercent: Double?,
    val hotThresholdC: Double?,
    val highThresholdC: Double?,
    val coldThresholdC: Double?,
    val currentRecordIndex: Int?,
    val currentSessionSecondsEstimate: Double?,
    val currentSessionLitersMeasured: Double?,
    val currentSessionAverageFlowLpm: Double?,
    val hotSecondsTotal: Int?,
    val coldSecondsTotal: Int?,
    val lastFinalizedRecordIndex: Int?,
    val lastFinalizedHotSeconds: Int?,
    val lastFinalizedColdSeconds: Int?,
    val hotColdFinalizationPending: Boolean,
    val intervalSeconds: Double?,
    val estimatedIntervalLiters: Double?,
    val estimatedIntervalLitersMin: Double?,
    val estimatedIntervalLitersMax: Double?,
    val intervalLitersMeasured: Double?,
    val intervalAverageFlowLpm: Double?,
    val sessionVolumeDeciliters: Int?,
    val sessionDurationSecondsRaw: Int?,
    val intervalVolumeDecilitersDelta: Int?,
    val usageUnitsDelta: Int?,
    val hotSecondsDelta: Int?,
    val coldSecondsDelta: Int?,
    val eventClockRaw: Long?,
    val flowTicksRaw: Int?,
    val flowTicksDelta: Int?,
    val sessionFlowTicksTotal: Int?,
    val sessionFlowTicksDelta: Int?,
    val timingBasis: String?,
    val hasHelloKleanHeader: Boolean,
    val notes: List<String>
) {
    fun toJson(): JSONObject = JSONObject().apply {
        putNullableLocal("temperature_c", temperatureC)
        putNullableLocal("temperature_raw_deci_c", temperatureRaw)
        put("temperature_confidence", if (temperatureC != null) "experimental_raw_candidate" else "unavailable")

        putNullableLocal("filter_total_units", filterTotalUnits)
        putNullableLocal("filter_warning_used_units", filterWarningUsedUnits)
        putNullableLocal("filter_used_units", filterUsedUnits)
        putNullableLocal("filter_remaining_units", filterRemainingUnits)
        putNullableLocal("filter_remaining_percent", filterRemainingPercent)
        put("filter_counter_confidence", if (filterTotalUnits != null && filterRemainingUnits != null) "high_structure_medium_unit" else "unavailable")

        putNullableLocal("threshold_hot_c", hotThresholdC)
        putNullableLocal("threshold_high_c", highThresholdC)
        putNullableLocal("threshold_cold_c", coldThresholdC)

        putNullableLocal("current_record_index", currentRecordIndex)
        putNullableLocal("current_session_seconds", currentSessionSecondsEstimate)
        // Backward-compatible alias retained for older exported JSON consumers.
        putNullableLocal("current_session_seconds_estimate", currentSessionSecondsEstimate)
        putNullableLocal("current_session_liters_measured", currentSessionLitersMeasured)
        putNullableLocal("current_session_average_flow_lpm", currentSessionAverageFlowLpm)
        putNullableLocal("session_volume_deciliters", sessionVolumeDeciliters)
        putNullableLocal("session_duration_seconds_raw", sessionDurationSecondsRaw)
        put("session_volume_confidence", if (currentSessionLitersMeasured != null) "high_controlled_30s_120s" else "unavailable")
        put("session_duration_confidence", if (currentSessionSecondsEstimate != null) "high_controlled_30s_120s" else "unavailable")
        put("session_schema", "0x0401 + n*28; +0x0A=0.1L, +0x0C=active-flow seconds")

        putNullableLocal("hot_seconds_total", hotSecondsTotal)
        putNullableLocal("cold_seconds_total", coldSecondsTotal)
        putNullableLocal("last_finalized_record_index", lastFinalizedRecordIndex)
        putNullableLocal("last_finalized_hot_seconds", lastFinalizedHotSeconds)
        putNullableLocal("last_finalized_cold_seconds", lastFinalizedColdSeconds)
        put("hot_cold_finalization_pending", hotColdFinalizationPending)
        put("hot_cold_confidence", "experimental; some records appear finalized only after rollover")

        putNullableLocal("interval_seconds", intervalSeconds)
        putNullableLocal("interval_liters_measured", intervalLitersMeasured)
        putNullableLocal("interval_average_flow_lpm", intervalAverageFlowLpm)
        putNullableLocal("interval_volume_deciliters_delta", intervalVolumeDecilitersDelta)
        put("interval_measurement_basis", "direct session record delta: 0.1 L/count + seconds")
        put("timing_confidence", if (intervalSeconds != null) "high_controlled_30s_120s" else "unavailable")
        put("volume_confidence", if (intervalLitersMeasured != null) "high_controlled_30s_120s" else "unavailable")

        // Legacy keys now mirror the directly measured interval volume. They are no longer estimates.
        putNullableLocal("estimated_interval_liters", estimatedIntervalLiters)
        putNullableLocal("estimated_interval_liters_min", estimatedIntervalLitersMin)
        putNullableLocal("estimated_interval_liters_max", estimatedIntervalLitersMax)
        put("liters_basis", "izravno dekodirano iz session polja +0x0A; 1 count = 0,1 L")

        putNullableLocal("usage_units_delta", usageUnitsDelta)
        putNullableLocal("hot_seconds_delta", hotSecondsDelta)
        putNullableLocal("cold_seconds_delta", coldSecondsDelta)

        putNullableLocal("event_clock_raw", eventClockRaw)
        putNullableLocal("aux_counter_02cc_raw", flowTicksRaw)
        putNullableLocal("aux_counter_02cc_delta", flowTicksDelta)
        // Legacy diagnostic aliases retained; not used by the decoder anymore.
        putNullableLocal("flow_ticks_raw", flowTicksRaw)
        putNullableLocal("flow_ticks_delta", flowTicksDelta)
        putNullableLocal("session_flow_ticks_total", sessionFlowTicksTotal)
        putNullableLocal("session_flow_ticks_delta", sessionFlowTicksDelta)
        putNullableLocal("timing_basis", timingBasis)
        put("production_confirmed_fields", org.json.JSONArray(listOf("session_volume_0.1L", "active_flow_seconds", "average_flow", "session_index", "filter_counter_structure")))
        put("experimental_fields", org.json.JSONArray(listOf("thermal_candidate", "hot_seconds", "cold_seconds", "event_clock", "aux_counter_02cc")))

        put("hello_klean_header_detected", hasHelloKleanHeader)
        put("notes", org.json.JSONArray(notes))
    }
}

data class DecodedShowerSession(
    val slot: Int,
    val index: Int,
    val clockRaw: Long,
    val volumeDeciliters: Int,
    val durationSeconds: Int,
    val averageFlowLpm: Double?,
    val hotSeconds: Int?,
    val coldSeconds: Int?
)

private data class SessionRecord(
    val offset: Int,
    val clockRaw: Long,
    val index: Int,
    val fields: IntArray
)

object ShowerMetricsDecoder {
    fun decodeSessionRecords(snapshot: NfcSnapshot): List<DecodedShowerSession> {
        val bytes = snapshot.metadata["NfcV.memory.dump_hex"].orEmpty().hexBytesOrNull() ?: return emptyList()
        return publicSessions(bytes)
    }

    fun decodeSessionRecordsFromJson(json: String?): List<DecodedShowerSession> {
        if (json.isNullOrBlank()) return emptyList()
        val root = runCatching { JSONObject(json) }.getOrNull() ?: return emptyList()
        val bytes = root.optJSONObject("technology_metadata")
            ?.optString("NfcV.memory.dump_hex")
            .orEmpty()
            .hexBytesOrNull() ?: return emptyList()
        return publicSessions(bytes)
    }

    fun tagIdFromJson(json: String?): String? {
        if (json.isNullOrBlank()) return null
        return runCatching { JSONObject(json).optJSONObject("tag")?.optString("id_hex") }
            .getOrNull()
            ?.takeIf { !it.isNullOrBlank() }
    }

    fun capturedAtFromJson(json: String?): java.time.Instant? {
        if (json.isNullOrBlank()) return null
        val value = runCatching { JSONObject(json).optString("captured_at_utc") }.getOrNull().orEmpty()
        return runCatching { java.time.Instant.parse(value) }.getOrNull()
    }

    fun decode(previousJson: String?, snapshot: NfcSnapshot): ShowerMetrics {
        val current = snapshot.metadata["NfcV.memory.dump_hex"].orEmpty().hexBytesOrNull()
        if (current == null || current.size < 8192) return emptyMetrics()

        val previousRoot = previousJson?.let { runCatching { JSONObject(it) }.getOrNull() }
        val previousBytes = previousRoot
            ?.optJSONObject("technology_metadata")
            ?.optString("NfcV.memory.dump_hex")
            .orEmpty()
            .hexBytesOrNull()
            ?.takeIf { it.size == current.size }

        val total = current.u16leSafe(FILTER_TOTAL_OFFSET)?.takeIf { it in 1000..20000 }
        val warning = current.u16leSafe(FILTER_WARNING_OFFSET)?.takeIf { it in 0..20000 }
        val used = mirroredValue(current.u16leSafe(USAGE_OFFSET), current.u16leSafe(USAGE_MIRROR_OFFSET))
        val remaining = mirroredValue(current.u16leSafe(REMAINING_OFFSET), current.u16leSafe(REMAINING_MIRROR_OFFSET))
        val remainingPercent = if (total != null && remaining != null && total > 0) {
            (remaining.toDouble() / total.toDouble() * 100.0).coerceIn(0.0, 100.0)
        } else null

        val temperatureRaw = TEMPERATURE_OFFSETS
            .map { current.u16leSafe(it) }
            .filterNotNull()
            .filter { it in 0..1000 }
            .let { values ->
                if (values.isEmpty()) null
                else {
                    val mostCommon = values.groupingBy { it }.eachCount().maxByOrNull { it.value }
                    if ((mostCommon?.value ?: 0) >= 2) mostCommon?.key else values.sorted()[values.size / 2]
                }
            }
        val temperatureC = temperatureRaw?.div(10.0)

        val highThresholdC = current.u16leSafe(TEMP_HIGH_OFFSET)?.takeIf { it in 100..900 }?.div(10.0)
        val hotThresholdC = current.u16leSafe(TEMP_HOT_OFFSET)?.takeIf { it in 100..900 }?.div(10.0)
        val coldThresholdC = current.u16leSafe(TEMP_COLD_OFFSET)?.takeIf { it in 0..900 }?.div(10.0)

        val records = parseSessionRecords(current)
        val latest = records.maxByOrNull { it.index }
        val previousRecords = previousBytes?.let(::parseSessionRecords).orEmpty()
        val previousMax = previousRecords.maxByOrNull { it.index }

        val sessionVolumeDl = latest?.fields?.getOrNull(SESSION_VOLUME_DL_FIELD)
        val sessionDurationSeconds = latest?.fields?.getOrNull(SESSION_DURATION_SECONDS_FIELD)
        val currentSessionLiters = sessionVolumeDl?.div(10.0)
        val currentSessionSeconds = sessionDurationSeconds?.toDouble()
        val currentSessionAverageFlow = averageFlowLpm(currentSessionLiters, currentSessionSeconds)

        val intervalVolumeDl = when {
            latest == null || previousMax == null || sessionVolumeDl == null -> null
            latest.index == previousMax.index -> {
                val before = previousMax.fields.getOrNull(SESSION_VOLUME_DL_FIELD)
                if (before != null) u16CounterDelta(sessionVolumeDl, before).takeIf { it <= 5000 } else null
            }
            latest.index == previousMax.index + 1 -> sessionVolumeDl
            else -> null
        }
        val intervalDurationSeconds = when {
            latest == null || previousMax == null || sessionDurationSeconds == null -> null
            latest.index == previousMax.index -> {
                val before = previousMax.fields.getOrNull(SESSION_DURATION_SECONDS_FIELD)
                if (before != null) u16CounterDelta(sessionDurationSeconds, before).takeIf { it <= 7200 } else null
            }
            latest.index == previousMax.index + 1 -> sessionDurationSeconds.takeIf { it <= 7200 }
            else -> null
        }
        val intervalLiters = intervalVolumeDl?.div(10.0)
        val intervalFlow = averageFlowLpm(intervalLiters, intervalDurationSeconds?.toDouble())

        val hotTotal = latest?.fields?.getOrNull(SESSION_HOT_FIELD)
        val coldTotal = latest?.fields?.getOrNull(SESSION_COLD_FIELD)
        val hotColdPending = latest != null &&
            (latest.fields.getOrNull(SESSION_DURATION_SECONDS_FIELD) ?: 0) > 0 &&
            (hotTotal ?: 0) == 0 && (coldTotal ?: 0) == 0

        val lastFinalized = when {
            latest == null -> null
            hotColdPending -> records.filter { it.index < latest.index }.maxByOrNull { it.index }
            else -> latest
        }
        val finalizedHot = lastFinalized?.fields?.getOrNull(SESSION_HOT_FIELD)
        val finalizedCold = lastFinalized?.fields?.getOrNull(SESSION_COLD_FIELD)

        val hotDelta = when {
            hotTotal == null || previousMax == null -> null
            latest?.index == previousMax.index -> {
                val before = previousMax.fields.getOrNull(SESSION_HOT_FIELD)
                if (before != null && hotTotal >= before) hotTotal - before else null
            }
            latest?.index == previousMax.index + 1 -> hotTotal
            else -> null
        }
        val coldDelta = when {
            coldTotal == null || previousMax == null -> null
            latest?.index == previousMax.index -> {
                val before = previousMax.fields.getOrNull(SESSION_COLD_FIELD)
                if (before != null && coldTotal >= before) coldTotal - before else null
            }
            latest?.index == previousMax.index + 1 -> coldTotal
            else -> null
        }

        val previousUsed = previousBytes?.let { bytes ->
            mirroredValue(bytes.u16leSafe(USAGE_OFFSET), bytes.u16leSafe(USAGE_MIRROR_OFFSET))
        }
        val usageDelta = if (used != null && previousUsed != null) used - previousUsed else null

        val eventClockRaw = current.u32leSafe(EVENT_CLOCK_OFFSET)
        val auxCounter = mirroredValue(current.u16leSafe(AUX_COUNTER_OFFSET), current.u16leSafe(AUX_COUNTER_MIRROR_OFFSET))
        val previousAux = previousBytes?.let { bytes ->
            mirroredValue(bytes.u16leSafe(AUX_COUNTER_OFFSET), bytes.u16leSafe(AUX_COUNTER_MIRROR_OFFSET))
        }
        val auxDelta = if (auxCounter != null && previousAux != null) u16CounterDelta(auxCounter, previousAux).takeIf { it <= 20000 } else null

        val header = current.indexOfAscii("HKSSH001") >= 0
        val visibleSessionLiters = records.sumOf { (it.fields.getOrNull(SESSION_VOLUME_DL_FIELD) ?: 0).toDouble() } / 10.0

        val notes = buildList {
            if (header) add("HKSSH001 vlasnički potpis potvrđen u EEPROM-u.")
            if (temperatureC != null) add("Toplinski kandidat postoji na četiri zrcaljene adrese (U16LE / 10), ali više se ne prikazuje kao potvrđena temperatura vode.")
            if (total != null && used != null && remaining != null && used + remaining == total) {
                add("HydraTrack/filter brojači ostaju konzistentni: $used + $remaining = $total. Njihova fizička jedinica još nije proglašena litrama.")
            }
            if (latest != null && currentSessionLiters != null && currentSessionSeconds != null) {
                add("Session #${latest.index}: %.1f L u %.0f s; prosječni protok %.2f L/min.".format(Locale.US, currentSessionLiters, currentSessionSeconds, currentSessionAverageFlow ?: 0.0))
            }
            if (intervalLiters != null && intervalDurationSeconds != null) {
                add("Od prethodnog očitanja session zapis izravno daje %.1f L i %d s; prosječni protok %.2f L/min.".format(Locale.US, intervalLiters, intervalDurationSeconds, intervalFlow ?: 0.0))
            }
            if (hotColdPending) add("Hot/cold polja aktualnog session zapisa još su 0; uređaj ih vjerojatno finalizira tek pri rolloveru na novi zapis.")
            if (lastFinalized != null && (finalizedHot != null || finalizedCold != null)) {
                add("Zadnji završeni session kandidat #${lastFinalized.index}: hot=${finalizedHot ?: 0}, cold=${finalizedCold ?: 0}.")
            }
            if (records.isNotEmpty()) add("Vidljiva session tablica trenutno zbraja %.1f L preko %d zapisa.".format(Locale.US, visibleSessionLiters, records.size))
            if (eventClockRaw != null) add("0x02C4 ostaje interni event/clock zapis i ne koristi se za trajanje protoka.")
            if (auxCounter != null) add("0x02CC/0x02CE ostaje pomoćni brojač; 0.5.0 ga ne pretvara u sekunde ni litre.")
        }

        return ShowerMetrics(
            temperatureC = temperatureC,
            temperatureRaw = temperatureRaw,
            filterTotalUnits = total,
            filterWarningUsedUnits = warning,
            filterUsedUnits = used,
            filterRemainingUnits = remaining,
            filterRemainingPercent = remainingPercent,
            hotThresholdC = hotThresholdC,
            highThresholdC = highThresholdC,
            coldThresholdC = coldThresholdC,
            currentRecordIndex = latest?.index,
            currentSessionSecondsEstimate = currentSessionSeconds,
            currentSessionLitersMeasured = currentSessionLiters,
            currentSessionAverageFlowLpm = currentSessionAverageFlow,
            hotSecondsTotal = hotTotal,
            coldSecondsTotal = coldTotal,
            lastFinalizedRecordIndex = lastFinalized?.index,
            lastFinalizedHotSeconds = finalizedHot,
            lastFinalizedColdSeconds = finalizedCold,
            hotColdFinalizationPending = hotColdPending,
            intervalSeconds = intervalDurationSeconds?.toDouble(),
            estimatedIntervalLiters = intervalLiters,
            estimatedIntervalLitersMin = null,
            estimatedIntervalLitersMax = null,
            intervalLitersMeasured = intervalLiters,
            intervalAverageFlowLpm = intervalFlow,
            sessionVolumeDeciliters = sessionVolumeDl,
            sessionDurationSecondsRaw = sessionDurationSeconds,
            intervalVolumeDecilitersDelta = intervalVolumeDl,
            usageUnitsDelta = usageDelta,
            hotSecondsDelta = hotDelta,
            coldSecondsDelta = coldDelta,
            eventClockRaw = eventClockRaw,
            flowTicksRaw = auxCounter,
            flowTicksDelta = auxDelta,
            sessionFlowTicksTotal = sessionDurationSeconds,
            sessionFlowTicksDelta = intervalDurationSeconds,
            timingBasis = "session +0x0C active-flow seconds; volume +0x0A at 0.1 L/count",
            hasHelloKleanHeader = header,
            notes = notes
        )
    }

    fun attachToJson(baseJson: String, metrics: ShowerMetrics): String {
        val root = JSONObject(baseJson)
        root.put("decoded_metrics", metrics.toJson())
        return root.toString(2)
    }

    fun fromJson(json: String?): ShowerMetrics? {
        if (json.isNullOrBlank()) return null
        val obj = runCatching { JSONObject(json).optJSONObject("decoded_metrics") }.getOrNull() ?: return null
        val intervalLiters = obj.optDoubleOrNull("interval_liters_measured") ?: obj.optDoubleOrNull("estimated_interval_liters")
        val currentSeconds = obj.optDoubleOrNull("current_session_seconds") ?: obj.optDoubleOrNull("current_session_seconds_estimate")
        return ShowerMetrics(
            temperatureC = obj.optDoubleOrNull("temperature_c"),
            temperatureRaw = obj.optIntOrNull("temperature_raw_deci_c"),
            filterTotalUnits = obj.optIntOrNull("filter_total_units"),
            filterWarningUsedUnits = obj.optIntOrNull("filter_warning_used_units"),
            filterUsedUnits = obj.optIntOrNull("filter_used_units"),
            filterRemainingUnits = obj.optIntOrNull("filter_remaining_units"),
            filterRemainingPercent = obj.optDoubleOrNull("filter_remaining_percent"),
            hotThresholdC = obj.optDoubleOrNull("threshold_hot_c"),
            highThresholdC = obj.optDoubleOrNull("threshold_high_c"),
            coldThresholdC = obj.optDoubleOrNull("threshold_cold_c"),
            currentRecordIndex = obj.optIntOrNull("current_record_index"),
            currentSessionSecondsEstimate = currentSeconds,
            currentSessionLitersMeasured = obj.optDoubleOrNull("current_session_liters_measured"),
            currentSessionAverageFlowLpm = obj.optDoubleOrNull("current_session_average_flow_lpm"),
            hotSecondsTotal = obj.optIntOrNull("hot_seconds_total"),
            coldSecondsTotal = obj.optIntOrNull("cold_seconds_total"),
            lastFinalizedRecordIndex = obj.optIntOrNull("last_finalized_record_index"),
            lastFinalizedHotSeconds = obj.optIntOrNull("last_finalized_hot_seconds"),
            lastFinalizedColdSeconds = obj.optIntOrNull("last_finalized_cold_seconds"),
            hotColdFinalizationPending = obj.optBoolean("hot_cold_finalization_pending", false),
            intervalSeconds = obj.optDoubleOrNull("interval_seconds"),
            estimatedIntervalLiters = intervalLiters,
            estimatedIntervalLitersMin = obj.optDoubleOrNull("estimated_interval_liters_min"),
            estimatedIntervalLitersMax = obj.optDoubleOrNull("estimated_interval_liters_max"),
            intervalLitersMeasured = intervalLiters,
            intervalAverageFlowLpm = obj.optDoubleOrNull("interval_average_flow_lpm"),
            sessionVolumeDeciliters = obj.optIntOrNull("session_volume_deciliters"),
            sessionDurationSecondsRaw = obj.optIntOrNull("session_duration_seconds_raw"),
            intervalVolumeDecilitersDelta = obj.optIntOrNull("interval_volume_deciliters_delta"),
            usageUnitsDelta = obj.optIntOrNull("usage_units_delta"),
            hotSecondsDelta = obj.optIntOrNull("hot_seconds_delta"),
            coldSecondsDelta = obj.optIntOrNull("cold_seconds_delta"),
            eventClockRaw = obj.optLongOrNull("event_clock_raw"),
            flowTicksRaw = obj.optIntOrNull("aux_counter_02cc_raw") ?: obj.optIntOrNull("flow_ticks_raw"),
            flowTicksDelta = obj.optIntOrNull("aux_counter_02cc_delta") ?: obj.optIntOrNull("flow_ticks_delta"),
            sessionFlowTicksTotal = obj.optIntOrNull("session_flow_ticks_total"),
            sessionFlowTicksDelta = obj.optIntOrNull("session_flow_ticks_delta"),
            timingBasis = obj.optStringOrNull("timing_basis"),
            hasHelloKleanHeader = obj.optBoolean("hello_klean_header_detected", false),
            notes = emptyList()
        )
    }

    private fun emptyMetrics() = ShowerMetrics(
        temperatureC = null,
        temperatureRaw = null,
        filterTotalUnits = null,
        filterWarningUsedUnits = null,
        filterUsedUnits = null,
        filterRemainingUnits = null,
        filterRemainingPercent = null,
        hotThresholdC = null,
        highThresholdC = null,
        coldThresholdC = null,
        currentRecordIndex = null,
        currentSessionSecondsEstimate = null,
        currentSessionLitersMeasured = null,
        currentSessionAverageFlowLpm = null,
        hotSecondsTotal = null,
        coldSecondsTotal = null,
        lastFinalizedRecordIndex = null,
        lastFinalizedHotSeconds = null,
        lastFinalizedColdSeconds = null,
        hotColdFinalizationPending = false,
        intervalSeconds = null,
        estimatedIntervalLiters = null,
        estimatedIntervalLitersMin = null,
        estimatedIntervalLitersMax = null,
        intervalLitersMeasured = null,
        intervalAverageFlowLpm = null,
        sessionVolumeDeciliters = null,
        sessionDurationSecondsRaw = null,
        intervalVolumeDecilitersDelta = null,
        usageUnitsDelta = null,
        hotSecondsDelta = null,
        coldSecondsDelta = null,
        eventClockRaw = null,
        flowTicksRaw = null,
        flowTicksDelta = null,
        sessionFlowTicksTotal = null,
        sessionFlowTicksDelta = null,
        timingBasis = null,
        hasHelloKleanHeader = false,
        notes = listOf("EEPROM nije potpuno pročitan; Smart Dashboard nije dekodiran.")
    )

    private fun publicSessions(bytes: ByteArray): List<DecodedShowerSession> =
        parseSessionRecords(bytes)
            .sortedBy { it.index }
            .mapIndexed { slot, record ->
                val volumeDl = record.fields.getOrNull(SESSION_VOLUME_DL_FIELD) ?: 0
                val duration = record.fields.getOrNull(SESSION_DURATION_SECONDS_FIELD) ?: 0
                DecodedShowerSession(
                    slot = slot,
                    index = record.index,
                    clockRaw = record.clockRaw,
                    volumeDeciliters = volumeDl,
                    durationSeconds = duration,
                    averageFlowLpm = averageFlowLpm(volumeDl / 10.0, duration.toDouble()),
                    hotSeconds = record.fields.getOrNull(SESSION_HOT_FIELD),
                    coldSeconds = record.fields.getOrNull(SESSION_COLD_FIELD)
                )
            }

    private fun parseSessionRecords(bytes: ByteArray): List<SessionRecord> {
        val out = mutableListOf<SessionRecord>()
        for (slot in 0 until SESSION_MAX_RECORDS) {
            val offset = SESSION_TABLE_OFFSET + slot * SESSION_RECORD_SIZE
            if (offset + SESSION_RECORD_SIZE > bytes.size) break
            val clock = bytes.u32leSafe(offset) ?: break
            val indexLong = bytes.u32leSafe(offset + 4) ?: break
            if (clock == 0L && indexLong == 0L) continue
            if (indexLong !in 1L..100000L) continue
            val fields = IntArray(10) { i -> bytes.u16leSafe(offset + 8 + i * 2) ?: 0 }
            out += SessionRecord(offset, clock, indexLong.toInt(), fields)
        }
        return out
    }

    private fun mirroredValue(a: Int?, b: Int?): Int? = when {
        a == null -> b
        b == null -> a
        a == b -> a
        else -> min(a, b).takeIf { max(a, b) - min(a, b) <= 1 } ?: a
    }

    private fun u16CounterDelta(current: Int, previous: Int): Int =
        if (current >= previous) current - previous else (65536 - previous) + current

    private fun averageFlowLpm(liters: Double?, seconds: Double?): Double? {
        if (liters == null || seconds == null || seconds <= 0.0) return null
        return liters * 60.0 / seconds
    }
}

private fun ByteArray.u16leSafe(offset: Int): Int? {
    if (offset < 0 || offset + 1 >= size) return null
    return (this[offset].toInt() and 0xFF) or ((this[offset + 1].toInt() and 0xFF) shl 8)
}

private fun ByteArray.u32leSafe(offset: Int): Long? {
    if (offset < 0 || offset + 3 >= size) return null
    return (this[offset].toLong() and 0xFF) or
        ((this[offset + 1].toLong() and 0xFF) shl 8) or
        ((this[offset + 2].toLong() and 0xFF) shl 16) or
        ((this[offset + 3].toLong() and 0xFF) shl 24)
}

private fun String.hexBytesOrNull(): ByteArray? {
    if (length < 2 || length % 2 != 0) return null
    return runCatching {
        ByteArray(length / 2) { i -> substring(i * 2, i * 2 + 2).toInt(16).toByte() }
    }.getOrNull()
}

private fun ByteArray.indexOfAscii(text: String): Int {
    val needle = text.toByteArray(Charsets.US_ASCII)
    if (needle.isEmpty() || needle.size > size) return -1
    for (i in 0..size - needle.size) {
        var ok = true
        for (j in needle.indices) {
            if (this[i + j] != needle[j]) {
                ok = false
                break
            }
        }
        if (ok) return i
    }
    return -1
}

private fun JSONObject.putNullableLocal(key: String, value: Any?) {
    if (value == null) put(key, JSONObject.NULL) else put(key, value)
}

private fun JSONObject.optIntOrNull(key: String): Int? =
    if (!has(key) || isNull(key)) null else runCatching { getInt(key) }.getOrNull()

private fun JSONObject.optLongOrNull(key: String): Long? =
    if (!has(key) || isNull(key)) null else runCatching { getLong(key) }.getOrNull()

private fun JSONObject.optDoubleOrNull(key: String): Double? =
    if (!has(key) || isNull(key)) null else runCatching { getDouble(key) }.getOrNull()

private fun JSONObject.optStringOrNull(key: String): String? =
    if (!has(key) || isNull(key)) null else optString(key).takeIf { it.isNotBlank() }
