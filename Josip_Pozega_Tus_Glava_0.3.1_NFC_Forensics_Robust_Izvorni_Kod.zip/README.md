# Josip Požega Tuš Glava 0.3.1 — NFC Forensics

Read-only Android aplikacija za forenzičko istraživanje Hello Klean Shower Head+ NFC telemetrije.

Novosti u 0.3.1:
- automatsko spremanje do 12 zadnjih očitanja
- automatska byte-by-byte usporedba s prethodnim očitanjem iste oznake
- changed_ranges s offsetima, starim/novim HEX vrijednostima i U8/U16/U32 interpretacijama
- detekcija HKSSH001 i ASCII tragova u EEPROM-u
- kandidati za 42.0/45.0/25.0 °C i druge poznate U16LE vrijednosti
- ST25DV read-only status: FTM static config, EH_CTRL_Dyn, MB_CTRL_Dyn i mailbox length
- VCC_ON detekcija za provjeru je li host elektronika napajana pri NFC očitanju
- mailbox sadržaj se namjerno NE čita jer čitanje zadnjeg bajta može promijeniti mailbox status
- cijeli 8192 B EEPROM dump ostaje dostupan u JSON-u

Aplikacija ne koristi write, lock, format, password-present niti druge naredbe koje mijenjaju stanje oznake.


## 0.3.1 robust scan
- EEPROM se čita prije ST25 dinamičkih registara.
- Adaptivni chunkovi 16→8→4→2→1 uz do 3 pokušaja.
- Nepotpuni dumpovi više se ne koriste kao forenzička baza.
- Kod neuspjeha bilježe se blok prekida, broj pročitanih bajtova i partial SHA-256.
